;(function() {
  const _tableState = {}
  const PAGE_SIZE = 15

  const el = (tag, attrs = {}, ...children) => {
    const e = document.createElement(tag)
    Object.entries(attrs).forEach(([k, v]) => {
      if (k.startsWith('on')) e.addEventListener(k.slice(2).toLowerCase(), v)
      else if (k === 'className') e.className = v
      else if (k === 'innerHTML') e.innerHTML = v
      else if (k === 'style' && typeof v === 'object') Object.assign(e.style, v)
      else if (k === 'selected' || k === 'checked' || k === 'disabled') e[k] = v
      else e.setAttribute(k, v)
    })
    children.forEach(c => { if (c != null) e.append(typeof c === 'string' ? document.createTextNode(c) : c) })
    return e
  }

  function sortableTable(id, columns, rows, opts = {}) {
    if (!_tableState[id]) _tableState[id] = { sortCol: -1, sortAsc: true, selected: new Set(), page: 0 }
    const st = _tableState[id]
    const ps = opts.pageSize || PAGE_SIZE
    const filtered = opts.filter ? rows.filter(opts.filter) : rows
    const sorted = st.sortCol >= 0
      ? [...filtered].sort((a, b) => st.sortAsc ? compareSort(a, b, st.sortCol, columns) : compareSort(b, a, st.sortCol, columns))
      : filtered
    const totalPages = Math.max(1, Math.ceil(sorted.length / ps))
    if (st.page >= totalPages) st.page = totalPages - 1
    if (st.page < 0) st.page = 0
    const paged = sorted.slice(st.page * ps, (st.page + 1) * ps)

    const container = el('div', { style: 'width:100%' })

    if (opts.bulkDelete) {
      const selCount = st.selected.size
      container.append(el('div', { style: 'display:flex;gap:8px;align-items:center;margin-bottom:8px' },
        el('span', { style: 'font-size:12px;color:#888' }, selCount ? `${selCount}개 선택` : ''),
        selCount ? el('button', { className: 'btn btn-sm btn-danger', onClick: () => {
          if (confirm(`${selCount}개를 삭제하시겠습니까?`)) {
            st.selected.forEach(k => opts.bulkDelete(k))
            st.selected.clear()
            rerender()
          }
        }}, `선택 삭제 (${selCount})`) : null,
        selCount ? el('button', { className: 'btn btn-sm btn-secondary', onClick: () => { st.selected.clear(); rerender() }}, '선택 해제') : null
      ))
    }

    const allChecked = paged.length > 0 && paged.every((_, i) => st.selected.has(id + '-r' + (st.page * ps + i)))
    const toggleAll = el('input', { type: 'checkbox', checked: allChecked, onChange: e => {
      const startIdx = st.page * ps
      if (e.target.checked) paged.forEach((_, i) => st.selected.add(id + '-r' + (startIdx + i)))
      else paged.forEach((_, i) => st.selected.delete(id + '-r' + (startIdx + i)))
      rerender()
    }})

    const thStyle = 'padding:8px 10px;border-bottom:2px solid #e0d8f0;font-size:12px;color:#555;font-weight:600'
    const ths = columns.map((col, ci) => {
      const isSorted = st.sortCol === ci
      const th = el('th', {
        style: `${thStyle};cursor:pointer;white-space:nowrap;user-select:none;text-align:${col.align || 'left'};${col.width ? 'width:' + col.width : ''}`,
        onClick: () => {
          if (st.sortCol === ci) st.sortAsc = !st.sortAsc
          else { st.sortCol = ci; st.sortAsc = true }
          rerender()
        }
      }, col.label + (isSorted ? (st.sortAsc ? ' ▲' : ' ▼') : ' ▽'))
      return th
    })

    const actionsHeader = opts.actions ? el('th', { style: `${thStyle};width:100px;text-align:center` }, '관리') : null
    const thead = el('tr', {},
      el('th', { style: `${thStyle};width:36px;text-align:center` }, toggleAll),
      el('th', { style: `${thStyle};width:40px;text-align:center` }, 'No'),
      ...ths,
      actionsHeader
    )

    const startNum = st.page * ps + 1
    const tbody = el('tbody', {}, ...paged.map((item, ri) => {
      const globalIdx = st.page * ps + ri
      const checked = st.selected.has(id + '-r' + globalIdx)
      const cb = el('input', { type: 'checkbox', checked, onChange: () => {
        if (checked) st.selected.delete(id + '-r' + globalIdx)
        else st.selected.add(id + '-r' + globalIdx)
        rerender()
      }})
      const cells = columns.map((col, ci) => {
        const val = typeof col.value === 'function' ? col.value(item, ci) : item[col.key]
        const td = el('td', { style: `padding:8px 10px;font-size:13px;text-align:${col.align || 'left'}` })
        if (val instanceof HTMLElement) td.append(val)
        else if (val != null) td.textContent = val
        else td.textContent = ''
        return td
      })
      return el('tr', { style: checked ? 'background:#f0f0ff' : '' },
        el('td', { style: 'padding:8px 6px;text-align:center;width:36px' }, cb),
        el('td', { style: 'padding:8px 6px;text-align:center;width:40px;font-size:12px;color:#999' }, String(startNum + ri)),
        ...cells,
        opts.actions ? el('td', { style: 'padding:8px 10px;text-align:center;white-space:nowrap' },
          ...(typeof opts.actions === 'function' ? opts.actions(item) : opts.actions)
        ) : null
      )
    }))

    if (!paged.length) {
      tbody.append(el('tr', {}, el('td', { style: 'padding:20px;text-align:center;color:#999', colspan: columns.length + 3 }, opts.emptyText || '등록된 데이터가 없습니다.')))
    }

    const table = el('table', { style: 'width:100%;border-collapse:collapse;font-size:13px;table-layout:fixed' }, el('thead', {}, thead), tbody)
    container.append(table)

    if (totalPages > 1) {
      const nav = el('div', { style: 'display:flex;justify-content:center;align-items:center;gap:6px;margin-top:10px;font-size:12px' })
      const mkPageBtn = (label, pg, disabled) => el('button', {
        className: 'btn btn-sm' + (disabled ? '' : ' btn-secondary'),
        style: disabled ? 'opacity:.4;cursor:default' : 'cursor:pointer',
        onClick: disabled ? null : () => { st.page = pg; rerender() }
      }, label)
      nav.append(mkPageBtn('◀', st.page - 1, st.page <= 0))
      const startP = Math.max(0, st.page - 2)
      const endP = Math.min(totalPages, startP + 5)
      for (let p = startP; p < endP; p++) {
        const btn = el('button', {
          className: 'btn btn-sm',
          style: p === st.page ? 'background:#7C3AED;color:#fff' : '',
          onClick: () => { st.page = p; rerender() }
        }, String(p + 1))
        nav.append(btn)
      }
      nav.append(mkPageBtn('▶', st.page + 1, st.page >= totalPages - 1))
      nav.append(el('span', { style: 'color:#888;margin-left:8px' }, `${sorted.length}건`))
      container.append(nav)
    } else if (sorted.length > 0) {
      container.append(el('div', { style: 'text-align:right;font-size:11px;color:#999;margin-top:4px' }, `${sorted.length}건`))
    }

    function rerender() { container.replaceWith(sortableTable(id, columns, rows, opts)) }
    return container
  }

  function compareSort(a, b, col, columns) {
    const ka = typeof columns[col].value === 'function' ? columns[col].value(a, col) : a[columns[col].key]
    const kb = typeof columns[col].value === 'function' ? columns[col].value(b, col) : b[columns[col].key]
    if (ka == null) return 1
    if (kb == null) return -1
    if (typeof ka === 'number' && typeof kb === 'number') return ka - kb
    return String(ka).localeCompare(String(kb), 'ko')
  }

  const modal = (title, body, saveLabel) => {
    document.getElementById('modal-title').textContent = title
    document.getElementById('modal-body').innerHTML = ''
    if (typeof body === 'string') document.getElementById('modal-body').innerHTML = body
    else document.getElementById('modal-body').append(body)
    document.getElementById('modal-save').textContent = saveLabel || '저장'
    document.getElementById('modal-save').style.display = ''
    document.getElementById('modal-overlay').classList.remove('hidden')
  }

  let _userListTab = 'all'
  let _helpOpen = false
  let _griAssId = null
  let _riskAssId = null
  let _monitorAssId = null
  let _monitorIndustry = 'mfg'

  const _helpTexts = {
    dashboard: `<strong>📊 대시보드</strong><br><br>
• 현재 ESG 평가 현황을 한눈에 확인합니다.<br>
• 점수, 테마 레이더 차트, 증빙 진행률, AI 초안 현황, 온실가스 배출량, 항목별 완료율을 카드 형태로 보여줍니다.<br>
• 평가를 먼저 생성해야 데이터가 표시됩니다.`,
    assessment: `<strong>📋 ESG 평가</strong><br><br>
• EcoVadis / KSSB / KCGS / NICE / K-ESG 기준의 평가를 생성·관리합니다.<br>
• <strong>+ 새 평가</strong> 버튼으로 평가를 추가하고, 각 평가의 점수·등급을 입력·수정할 수 있습니다.<br>
• 평가를 삭제하면 연결된 모든 데이터(항목·증빙·AI 초안)도 함께 삭제됩니다.`,
    indicator: `<strong>📌 지표 관리</strong><br><br>
• 평가 기관별 지표를 조회하고 활성/비활성 전환합니다.<br>
• 상단 드롭다운으로 기관(EcoVadis 21개 항목, KSSB 등)을 전환할 수 있습니다.<br>
• 비활성화된 지표는 평가 화면에서 제외됩니다.`,
    evidence: `<strong>📎 증빙 관리</strong><br><br>
• 각 평가 지표에 필요한 증빙 자료를 등록·관리합니다.<br>
• 증빙 상태: 자가입력 → 내부검토완료 → 외부검증완료 순으로 관리됩니다.<br>
• 관리자만 민감정보(급여, 인사정보 등)를 조회할 수 있습니다.`,
    ghg: `<strong>🏭 온실가스</strong><br><br>
• Scope 1(직접), Scope 2(에너지 간접·위치/시장 기준), Scope 3(가치사슬) 배출량을 계산합니다.<br>
• 활동자료(에너지 사용량)를 입력하면 IPCC/KEPCO 기반 배출계수로 자동 계산됩니다.<br>
• 상단 요약 영역에서 Scope별 합계를 확인할 수 있습니다.`,
    supplier: `<strong>🏢 협력사 리스크</strong><br><br>
• 협력사 정보를 등록하고 VSME(중소기업 자율보고) 자가진단을 수행합니다.<br>
• <strong>기본 모드</strong>: 12개 항목 (환경·사회·지배구조 기본 정책/체크)<br>
• <strong>종합 모드</strong>: 14개 항목 (정량 KPI, 인증, 목표 포함)<br>
• 자가진단 결과에 따라 협력사 리스크 등급(A/B/C/D)이 자동 산정됩니다.`,
    ai: `<strong>🤖 AI 보고서</strong><br><br>
• OpenCode AI를 활용하여 지속가능경영보고서를 자동 생성합니다.<br>
• 생성된 보고서는 <strong>검증</strong> 단계를 거쳐 증빙-텍스트 연결이 강제됩니다.<br>
• 초안 상태: 초안 → 검증완료 → 승인됨 순서로 진행됩니다.`,
    editor: `<strong>📝 보고서 편집기 (S-05)</strong><br><br>
• 지표별로 연결할 증빙을 관리하는 화면입니다.<br>
• <strong>지표 ↔ 증빙 다대다 연결</strong>: 보고서 편집기에서만 연결 작업을 수행합니다.<br>
• 연결된 증빙만 AI 프롬프트에 전달됩니다.<br>
• 미연결 문장은 AI 검증에서 UNSUPPORTED로 표시되고, 최종 승인이 차단됩니다.`,
    settings: `<strong>⚙️ 설정</strong><br><br>
• <strong>사용자 관리</strong>: 가입 승인/거절, 권한 변경, 계정 삭제<br>
• <strong>접속 유지</strong>: Supabase 무료 요금제 중단 방지를 위한 자동 접속 (6일 간격)<br>
• <strong>모바일 접속</strong>: QR코드로 모바일 페이지에 접속할 수 있습니다.`,
    gri: `<strong>📊 GRI 준수율</strong><br><br>
• GRI Standards에 대한 자사 준수 현황을 분석합니다.<br>
• 완전준수(70점 이상) / 부분준수(30~69점) / 미준수(30점 미만)로 구분합니다.<br>
• 필수 항목 34개 기준으로 준수율을 계산합니다.`,
    risk: `<strong>⚠️ 리스크 예측</strong><br><br>
• 6개 카테고리(기후변화, 자원고갈, 생태계, 인권/노동, 지배구조, 공급망)의 리스크를 분석합니다.<br>
• 전년 대비 추세 변화를 감지하고 알림을 생성합니다.<br>
• AI 기반 리스크 점수와 등급을 산정합니다.`,
    monitor: `<strong>📈 벤치마크</strong><br><br>
• 8개 업종별 EcoVadis 평균 점수와 자사를 비교합니다.<br>
• 글로벌 평균(51점) 대비 상대적 위치를 분석합니다.<br>
• 업종별 랭킹 차트를 제공합니다.`,
    issa: `<strong>🛡️ 감사 보증</strong><br><br>
• ISSA 5000 국제 표준에 따른 외부 감사 보증 워크플로우를 관리합니다.<br>
• 4단계 감사(계획→실사→결론→보증)를 추적합니다.<br>
• 지적사항 관리, 보증 의견서 자동 생성을 지원합니다.`,
    submit: `<strong>📤 평가기관 제출</strong><br><br>
• EcoVadis, CDP, GRI, TCFD, SBTi 등 8개 평가기관에 대한 제출 준비를 관리합니다.<br>
• 기관별 필수 체크리스트를 관리하고 제출 준비율을 확인합니다.<br>
• EcoVadis CSV 등 기관별 포맷으로 데이터를 내보낼 수 있습니다.`,
    api: `<strong>🔌 API 연동</strong><br><br>
• ERP, HR, 조달, 재무 시스템과의 데이터 연동 인터페이스를 관리합니다.<br>
• CSV 파일 가져오기로 GHG, 에너지, 인력 데이터를 일괄 등록합니다.<br>
• 10개 엔드포인트의 상태와 동기화 이력을 모니터링합니다.`,
    kssb: `<strong>📜 KSSB 공시관리</strong><br><br>
• KSSB 공시기준 제1호(일반사항)/제2호(기후) 항목별 작성 관리 화면입니다.<br>
• <strong>법정 의무(MANDATORY)</strong> 항목으로, 미공시 시 과태료가 부과됩니다.<br>
• Scope2 이중보고(위치기준+시장기준) 대상 지표를 표시합니다.`,
    aihistory: `<strong>🕐 AI 생성이력 검토 (S-13)</strong><br><br>
• AI가 생성한 모든 초안의 이력을 시간순으로 확인합니다.<br>
• 검증 통과 후 사람 검토를 기다리는 건을 승인/반려할 수 있습니다.<br>
• 마스킹 적용 여부를 확인할 수 있습니다.`,
    budget: `<strong>💰 예산/위험관리 (S-14)</strong><br><br>
• 프로젝트 예산 집행 현황을 관리합니다.<br>
• 리스크 레지스터에서 리스크를 등록하고 확률×영향 점수로 관리합니다.`,
    masking: `<strong>🔒 마스킹 설정 (S-15)</strong><br><br>
• AI 외부 API 전송 전 적용할 민감정보 마스킹 규칙을 정의합니다.<br>
• 전체마스킹/부분마스킹/집계치만허용 3가지 유형을 지원합니다.`
  }

  function init() {
    document.getElementById('version-label').textContent = '지속가능경영보고서 시스템 ' + Store.version
    const vb = document.getElementById('version-badge')
    if (vb) vb.textContent = Store.version
    ensureAdmin()
    GHG.init()
    checkAuth().then(user => {
      applyAuthUI()
      if (user) {
        document.getElementById('app').style.display = 'flex'
        navigate('dashboard')
      } else {
        showAuthModal('login')
      }
    })
    initKeepAlive()
  }

  // ==================== Navigation ====================
  function navigate(page) {
    document.querySelectorAll('#nav a').forEach(a => a.classList.remove('active'))
    document.querySelectorAll('.page').forEach(p => p.classList.remove('active'))
    const link = document.querySelector(`#nav a[data-page="${page}"]`)
    if (link) link.classList.add('active')
    const pageEl = document.getElementById('page-' + page)
    if (pageEl) pageEl.classList.add('active')
    const label = link ? link.textContent.replace(/^[^\s]+\s/, '') : page
    document.getElementById('page-title').textContent = label
    history.replaceState(null, '', '#' + page)
    if (_helpOpen) showHelpFor(page)

    const _safe = (fn) => { try { fn() } catch (e) { console.error('Render error [' + page + ']:', e); const c = document.getElementById('page-' + page); if (c) { c.innerHTML = ''; c.append(el('div', { className: 'card' }, el('div', { style: 'padding:20px;color:#e74c3c' }, el('h3', { style: 'margin:0 0 8px' }, '오류가 발생했습니다'), el('p', { style: 'margin:0 0 12px;font-size:13px' }, e.message), el('button', { className: 'btn btn-secondary', onClick: () => navigate(page) }, '다시 시도')))) } } }
    if (page === 'dashboard') _safe(renderDashboard)
    else if (page === 'assessment') _safe(renderAssessments)
    else if (page === 'indicator') _safe(renderIndicators)
    else if (page === 'evidence') _safe(renderEvidenceMgmt)
    else if (page === 'ghg') _safe(renderGHG)
    else if (page === 'supplier') _safe(renderSupplier)
    else if (page === 'ai') _safe(renderAI)
    else if (page === 'editor') _safe(renderReportEditor)
    else if (page === 'gri') _safe(renderGRI)
    else if (page === 'risk') _safe(renderRisk)
    else if (page === 'monitor') _safe(renderMonitor)
    else if (page === 'issa') _safe(renderISSA)
    else if (page === 'submit') _safe(renderSubmit)
    else if (page === 'kssb') _safe(renderKSSB)
    else if (page === 'aihistory') _safe(renderAIHistory)
    else if (page === 'budget') _safe(renderBudget)
    else if (page === 'masking') _safe(renderMasking)
    else if (page === 'api') _safe(renderAPI)
    else if (page === 'settings') _safe(() => switchSettingsTab('tab-users'))
  }

  function showHelpFor(page) {
    document.getElementById('help-content').innerHTML = _helpTexts[page] || '<strong>도움말</strong><br><br>선택한 페이지에 대한 도움말이 준비 중입니다.'
  }

  function toggleHelp() {
    _helpOpen = !_helpOpen
    const panel = document.getElementById('help-panel')
    if (_helpOpen) {
      const page = document.querySelector('#nav a.active')?.dataset?.page || 'dashboard'
      showHelpFor(page)
      panel.classList.remove('hidden')
    } else {
      panel.classList.add('hidden')
    }
  }

  // ==================== ESG 평가 ====================
  let _currentAssessmentId = null

  function renderAssessments() {
    const c = document.getElementById('page-assessment')
    const assessments = Store.getAssessments()
    c.innerHTML = ''
    c.append(
      el('div', { className: 'card' },
        el('div', { className: 'card-header' },
          el('h3', {}, 'ESG 평가 목록'),
          el('button', { className: 'btn btn-primary', onClick: openAddAssessment }, '+ 새 평가')
        ),
        sortableTable('assessments', [
          { label: '제목', key: 'title', value: a => a.title || '-' },
          { label: '기관', value: a => Indicator.getAuthorityName(a.authority_code) },
          { label: '유형', value: a => { const agencies = Store.getAgencyMaster ? Store.getAgencyMaster() : []; const ag = agencies.find(x => x.code === a.authority_code); return typeBadge(ag?.track_type) }, align: 'center' },
          { label: '연도', key: 'assessment_year', align: 'center' },
          { label: '상태', value: a => statusBadge(a.status), align: 'center' },
          { label: '총점', value: a => a.total_score != null ? a.total_score.toFixed(1) : '-', align: 'center' },
          { label: '등급', key: 'rating', align: 'center' }
        ], assessments, {
          bulkDelete: id => Store.deleteAssessmentCascade(id),
          actions: a => [
            el('button', { className: 'btn btn-sm btn-primary', style: { marginRight: 4 }, onClick: () => showAssessmentDetail(a.id) }, '점수'),
            el('button', { className: 'btn btn-sm btn-secondary', style: { marginRight: 4 }, onClick: () => editAssessment(a.id) }, '수정'),
            el('button', { className: 'btn btn-sm btn-danger', onClick: () => { if (confirm('정말 삭제?')) { Store.deleteAssessmentCascade(a.id); if (_currentAssessmentId === a.id) _currentAssessmentId = null; renderAssessments() } } }, '삭제')
          ]
        })
      )
    )
  }

  function statusBadge(status) {
    const colors = { draft: '#95a5a6', in_review: '#f39c12', verified: '#3498db', approved: '#27ae60', pending: '#f39c12', rejected: '#e74c3c' }
    const labels = { draft: '초안', in_review: '검토중', verified: '검증완료', approved: '승인됨', pending: '대기', rejected: '반려' }
    return el('span', { style: `background:${colors[status] || '#95a5a6'};color:#fff;padding:2px 8px;border-radius:10px;font-size:11px;font-weight:600` }, labels[status] || status || '-')
  }

  function typeBadge(trackType) {
    const isMandatory = trackType === 'MANDATORY'
    return el('span', { style: `background:${isMandatory ? '#e74c3c' : '#95a5a6'};color:#fff;padding:2px 8px;border-radius:10px;font-size:11px;font-weight:600` }, isMandatory ? '법정 의무' : '자율')
  }

  function evidenceStatusBadge(status) {
    const colors = { self: '#f39c12', internal_reviewed: '#3498db', externally_verified: '#27ae60' }
    const labels = { self: '자가', internal_reviewed: '내부검토', externally_verified: '외부검증' }
    return el('span', { style: `background:${colors[status] || '#95a5a6'};color:#fff;padding:2px 8px;border-radius:10px;font-size:11px;font-weight:600` }, labels[status] || status || '-')
  }

  function showAssessmentDetail(id) {
    _currentAssessmentId = id
    const a = Store.getAssessments().find(x => x.id === id)
    if (!a) return
    const c = document.getElementById('page-assessment')
    const items = Store.getAssessmentItems().filter(i => i.assessment_id === id)
    const groups = Indicator.getGroups(a.authority_code)
    const allIndicators = Store.getIndicators().filter(i => i.authority_code === a.authority_code && i.is_active !== false)
    const nextStatus = { draft: 'in_review', in_review: 'verified', verified: 'approved', approved: null }
    const statusLabels = { draft: '검토 요청', in_review: '검증 완료', verified: '승인', approved: null }

    c.innerHTML = ''
    c.append(
      el('div', { className: 'card' },
        el('div', { className: 'card-header' },
          el('div', {},
            el('h3', { style: 'margin:0' }, a.title || '평가 상세'),
            el('div', { style: 'font-size:12px;color:#888;margin-top:4px' }, `${Indicator.getAuthorityName(a.authority_code)} · ${a.assessment_year}년${(() => { const agencies = Store.getAgencyMaster ? Store.getAgencyMaster() : []; const ag = agencies.find(x => x.code === a.authority_code); return ag ? (ag.track_type === 'MANDATORY' ? ' <span style="background:#e74c3c;color:#fff;padding:1px 6px;border-radius:4px;font-size:10px;margin-left:4px">법정 의무</span>' : ' <span style="background:#95a5a6;color:#fff;padding:1px 6px;border-radius:4px;font-size:10px;margin-left:4px">자율 공시</span>') : '' })()}`)
          ),
          el('div', { style: 'display:flex;gap:6px;align-items:center' },
            el('span', {}, statusBadge(a.status)),
            nextStatus[a.status] ? el('button', { className: 'btn btn-sm btn-primary', onClick: () => transitionStatus(id) }, statusLabels[a.status]) : null,
            el('button', { className: 'btn btn-sm btn-secondary', onClick: renderAssessments }, '← 목록')
          )
        ),
        el('div', { style: 'padding:16px 20px;display:flex;gap:24px;font-size:13px;border-bottom:1px solid #eee' },
          el('span', {}, `총점: <strong>${a.total_score != null ? a.total_score.toFixed(1) : '-'}</strong>`),
          el('span', {}, `등급: <strong>${a.rating || '-'}</strong>`),
          el('span', {}, `항목: ${allIndicators.length}개 / 입력: ${items.length}개`)
        )
      ),
      ...groups.map(g => {
        const inds = allIndicators.filter(i => i.group_id === g.id)
        const weight = Store.getWeightParams().find(w => w.authority_code === a.authority_code && w.group_code === g.group_code && w.year === (a.assessment_year || 2026))
        const pillarParams = Store.getWeightParams().filter(w => w.authority_code === 'ECOVADIS' && w.group_code === '_PILLAR' && w.year === (a.assessment_year || 2026))
        const pillarNote = a.authority_code === 'ECOVADIS' && pillarParams.length
          ? pillarParams.map(p => `${Indicator.getPillarName(p.pillar)} ${p.weight_pct}%`).join(' / ')
          : (weight ? `가중치 ${weight.weight_pct}%` : '')
        return el('div', { className: 'card' },
          el('div', { className: 'card-header' },
            el('h3', { style: 'font-size:14px' }, `${Indicator.getGroupDisplayName(g)} ${pillarNote ? `- ${pillarNote}` : ''}`)
          ),
          el('table', { style: 'font-size:13px' },
            el('thead', {}, el('tr', {}, el('th', { style: 'width:80px' }, '코드'), el('th', {}, '지표'), el('th', {}, '필러'), el('th', { style: 'width:80px;text-align:center' }, '점수(0-100)'), el('th', { style: 'width:60px;text-align:center' }, '완료'))),
            el('tbody', {}, ...inds.map(ind => {
              const item = items.find(i => i.indicator_id === ind.id)
              return el('tr', {},
                el('td', { style: 'font-weight:500' }, ind.indicator_code),
                el('td', {}, Indicator.getDisplayName(ind)),
                el('td', {}, Indicator.getPillarName(ind.pillar)),
                el('td', { style: 'text-align:center' },
                  el('input', { type: 'number', min: 0, max: 100, step: 1, value: item?.score ?? '', style: 'width:70px;padding:4px 6px;border:1px solid #ddd;border-radius:6px;text-align:center;font-size:13px', onInput: () => saveItemScore(id, ind.id, weight?.id, weight?.weight_pct || 25) })
                ),
                el('td', { style: 'text-align:center' },
                  item ? el('span', { style: 'color:#27ae60;font-size:16px' }, '✓') : el('span', { style: 'color:#ccc;font-size:16px' }, '—')
                )
              )
            }))
          )
        )
      })
    )
  }

  function saveItemScore(assessmentId, indicatorId, weightId, weightPct) {
    const score = parseInt(event.target.value)
    if (isNaN(score) || score < 0 || score > 100) return
    const items = Store.getAssessmentItems()
    const existing = items.find(i => i.assessment_id === assessmentId && i.indicator_id === indicatorId)
    if (existing) {
      Store.updateAssessmentItem(existing.id, { score, weight_id: weightId, weight_pct: weightPct, updated_at: new Date().toISOString() })
    } else {
      Store.addAssessmentItem({ assessment_id: assessmentId, indicator_id: indicatorId, score, weight_id: weightId, weight_pct: weightPct, status: 'completed' })
    }
    calcAssessmentScore(assessmentId)
  }

  function calcAssessmentScore(id) {
    const a = Store.getAssessments().find(x => x.id === id)
    if (!a) return
    const items = Store.getAssessmentItems().filter(i => i.assessment_id === id)
    if (!items.length) return
    const year = a.assessment_year || 2026
    const usePillarWeight = a.authority_code === 'ECOVADIS'
    let totalWeighted = 0
    let totalWeight = 0
    if (usePillarWeight) {
      const pillarParams = Store.getWeightParams().filter(w => w.authority_code === 'ECOVADIS' && w.group_code === '_PILLAR' && w.year === year)
      const pillars = ['POLICY', 'ACTION', 'RESULT']
      pillars.forEach(p => {
        const pillarItems = items.filter(i => {
          const ind = Store.getIndicators().find(x => x.id === i.indicator_id)
          return ind && ind.pillar === p
        })
        if (!pillarItems.length) return
        const pw = pillarParams.find(pp => pp.pillar === p)
        const w = pw ? pw.weight_pct / 100 : (1 / pillars.length)
        const avg = pillarItems.reduce((s, i) => s + (i.score || 0), 0) / pillarItems.length
        totalWeighted += avg * w
        totalWeight += w
      })
    } else {
      const groups = Indicator.getGroups(a.authority_code)
      groups.forEach(g => {
        const groupItems = items.filter(i => {
          const ind = Store.getIndicators().find(x => x.id === i.indicator_id)
          return ind && ind.group_id === g.id
        })
        if (!groupItems.length) return
        const weight = Store.getWeightParams().find(w => w.authority_code === a.authority_code && w.group_code === g.group_code && w.year === year)
        const w = weight ? weight.weight_pct / 100 : (1 / groups.length)
        const avg = groupItems.reduce((s, i) => s + (i.score || 0), 0) / groupItems.length
        totalWeighted += avg * w
        totalWeight += w
      })
    }
    const finalScore = totalWeight > 0 ? totalWeighted / totalWeight : 0
    const thresholds = Store.getRatingThresholds().filter(t => t.authority_code === a.authority_code && t.year === year)
    let rating = '-'
    for (const t of thresholds.sort((a, b) => b.min_score - a.min_score)) {
      if (finalScore >= t.min_score && finalScore <= t.max_score) { rating = t.rating; break }
    }
    Store.updateAssessment(id, { total_score: finalScore, rating })
    showAssessmentDetail(id)
  }

  function transitionStatus(id) {
    const a = Store.getAssessments().find(x => x.id === id)
    if (!a) return
    const next = { draft: 'in_review', in_review: 'verified', verified: 'approved' }[a.status]
    if (!next) return
    Store.updateAssessment(id, { status: next })
    showAssessmentDetail(id)
  }

  function openAddAssessment() { createAssessmentModal() }
  function editAssessment(id) { const a = Store.getAssessments().find(x => x.id === id); if (a) createAssessmentModal(a) }

  function createAssessmentModal(a) {
    const isEdit = !!a
    const form = el('form', { onSubmit: e => { e.preventDefault(); submit() } })
    const title = el('input', { value: a?.title ?? '' })
    const year = el('input', { type: 'number', value: a?.assessment_year ?? new Date().getFullYear() - 1 })
    const authority = el('select', {},
      ['ECOVADIS', 'KSSB', 'KCGS', 'NICE', 'K-ESG'].map(c => el('option', { value: c, selected: a?.authority_code === c }, Indicator.getAuthorityName(c)))
    )
    form.append(
      el('label', {}, '평가 제목', title),
      el('label', {}, '평가 기관', authority),
      el('label', {}, '대상 연도', year)
    )
    modal(isEdit ? '평가 수정' : '새 ESG 평가', form)
    document.getElementById('modal-save').onclick = function save() {
      const data = { title: title.value, assessment_year: parseInt(year.value), authority_code: authority.value, status: 'draft' }
      if (isEdit) {
        Store.updateAssessment(a.id, data)
      } else {
        const created = Store.addAssessment(data)
        const activeIndicators = Store.getIndicators().filter(i => i.authority_code === authority.value && i.is_active !== false)
        const weightParams = Store.getWeightParams().filter(w => w.authority_code === authority.value && w.year === (parseInt(year.value) || 2026))
        activeIndicators.forEach(ind => {
          const w = weightParams.find(p => p.group_code === Store.getIndicatorGroups().find(g => g.id === ind.group_id)?.group_code)
          Store.addAssessmentItem({ assessment_id: created.id, indicator_id: ind.id, weight_id: w?.id, weight_pct: w?.weight_pct || 0, status: 'pending' })
        })
      }
      closeModal()
      renderAssessments()
    }
  }

  // ==================== 지표 관리 ====================
  let _selectedAuthority = 'ECOVADIS'
  let _materialityFilter = 'all'
  let _indicatorTab = 'list'
  let _indicatorSearch = ''
  let _selectedIndicators = new Set()
  let _editingIndicator = null
  let _showQuickForm = false

  function renderIndicators() {
    const c = document.getElementById('page-indicator')
    if (!c) return
    c.innerHTML = ''
    const allIndicators = Store.getIndicators().filter(i => i.authority_code === _selectedAuthority)
    const totalCount = allIndicators.length
    const activeCount = allIndicators.filter(i => i.is_active !== false).length
    const groups = Indicator.getGroups(_selectedAuthority)

    c.append(
      el('div', { style: 'display:flex;gap:6px;margin-bottom:12px' },
        el('button', { className: 'btn' + (_indicatorTab === 'list' ? ' btn-primary' : ''), onClick: () => { _indicatorTab = 'list'; renderIndicators() } }, '📋 지표 목록'),
        el('button', { className: 'btn' + (_indicatorTab === 'mapping' ? ' btn-primary' : ''), onClick: () => { _indicatorTab = 'mapping'; renderIndicators() } }, '🔗 매핑 관리')
      ),
      _indicatorTab === 'list' ? renderIndicatorListInline() : renderIndicatorMapping()
    )
  }

  function renderIndicatorListInline() {
    const allIndicators = Store.getIndicators().filter(i => i.authority_code === _selectedAuthority)
    const groups = Indicator.getGroups(_selectedAuthority)
    const filtered = allIndicators.filter(i => {
      if (_indicatorSearch) {
        const q = _indicatorSearch.toLowerCase()
        const nameMatch = (i.indicator_name || '').toLowerCase().includes(q)
        const codeMatch = (i.indicator_code || '').toLowerCase().includes(q)
        if (!nameMatch && !codeMatch) return false
      }
      if (_materialityFilter === 'active' && i.is_active === false) return false
      if (_materialityFilter === 'inactive' && i.is_active !== false) return false
      return true
    })
    const activeCount = allIndicators.filter(i => i.is_active !== false).length

    const wrapper = el('div')

    wrapper.append(
      el('div', { className: 'card', style: 'padding:12px 16px;display:flex;gap:12px;align-items:center;flex-wrap:wrap' },
        el('select', { id: 'authSelect', style: 'font-size:13px;padding:6px 10px;border:1px solid #ddd;border-radius:6px', onChange: () => { _selectedAuthority = document.getElementById('authSelect').value; _materialityFilter = 'all'; _indicatorSearch = ''; _selectedIndicators.clear(); renderIndicators() } },
          ['ECOVADIS', 'KSSB', 'KCGS', 'NICE', 'K-ESG'].map(code => el('option', { value: code, selected: code === _selectedAuthority }, Indicator.getAuthorityName(code)))
        ),
        el('input', { id: 'indSearch', type: 'text', placeholder: '🔍 지표명 또는 코드 검색...', value: _indicatorSearch, style: 'flex:1;min-width:200px;font-size:13px;padding:6px 10px;border:1px solid #ddd;border-radius:6px', onInput: () => { _indicatorSearch = document.getElementById('indSearch').value; renderIndicators() } }),
        el('select', { id: 'materialityFilter', style: 'font-size:13px;padding:6px 10px;border:1px solid #ddd;border-radius:6px', onChange: () => { _materialityFilter = document.getElementById('materialityFilter').value; renderIndicators() } },
          el('option', { value: 'all', selected: _materialityFilter === 'all' }, '전체'),
          el('option', { value: 'active', selected: _materialityFilter === 'active' }, `활성 (${activeCount})`),
          el('option', { value: 'inactive', selected: _materialityFilter === 'inactive' }, `비활성 (${allIndicators.length - activeCount})`)
        ),
        el('span', { style: 'font-size:12px;color:#888' }, `${filtered.length}개 표시 / ${allIndicators.length}개 전체`)
      )
    )

    if (_selectedIndicators.size > 0) {
      wrapper.append(
        el('div', { className: 'card', style: 'padding:10px 16px;display:flex;gap:8px;align-items:center;background:#f8f6ff;border-left:3px solid #7C3AED' },
          el('span', { style: 'font-size:13px;font-weight:600' }, `${_selectedIndicators.size}개 선택됨`),
          el('button', { className: 'btn btn-sm btn-primary', onClick: () => { _selectedIndicators.forEach(id => Store.updateIndicator(id, { is_active: true })); _selectedIndicators.clear(); renderIndicators() } }, '활성화'),
          el('button', { className: 'btn btn-sm btn-secondary', onClick: () => { _selectedIndicators.forEach(id => Store.updateIndicator(id, { is_active: false })); _selectedIndicators.clear(); renderIndicators() } }, '비활성화'),
          el('button', { className: 'btn btn-sm btn-danger', onClick: () => { if (confirm(`${_selectedIndicators.size}개 지표를 삭제하시겠습니까?`)) { _selectedIndicators.forEach(id => Store.deleteIndicator(id)); _selectedIndicators.clear(); renderIndicators() } } }, '삭제'),
          el('button', { className: 'btn btn-sm', style: 'margin-left:auto', onClick: () => { _selectedIndicators.clear(); renderIndicators() } }, '선택 해제')
        )
      )
    }

    if (_showQuickForm) {
      wrapper.append(renderQuickIndicatorForm())
    }

    wrapper.append(
      el('div', { className: 'card-header', style: 'display:flex;justify-content:space-between;align-items:center;padding:12px 16px' },
        el('h3', { style: 'margin:0;font-size:15px' }, `지표 관리 · ${Indicator.getAuthorityName(_selectedAuthority)}`),
        el('div', { style: 'display:flex;gap:6px' },
          el('button', { className: 'btn btn-sm', style: 'background:#f0f7ff;color:#3B82F6', onClick: () => openImportTemplate() }, '📥 템플릿에서 가져오기'),
          el('button', { className: 'btn btn-sm btn-primary', onClick: () => { _showQuickForm = !_showQuickForm; _editingIndicator = null; renderIndicators() } }, _showQuickForm ? '✕ 닫기' : '+ 새 지표 추가')
        )
      )
    )

    _selectedAuthority === 'ECOVADIS' && wrapper.append(
      el('div', { style: 'padding:10px 16px;background:#f8f6ff;border-bottom:1px solid #eee;font-size:12px;color:#666' },
        '📊 EcoVadis 공식 가중치: Policies 25% / Actions 40% / Results 35% (자사 참고용 사전진단)'
      )
    )

    if (!filtered.length) {
      wrapper.append(
        el('div', { className: 'card', style: 'text-align:center;padding:40px 20px' },
          el('div', { style: 'font-size:36px;margin-bottom:12px' }, '📋'),
          el('p', { style: 'margin:0 0 12px;color:#888' }, _indicatorSearch ? `"${_indicatorSearch}"에 대한 검색 결과가 없습니다` : '등록된 지표가 없습니다'),
          !_showQuickForm && el('button', { className: 'btn btn-primary', onClick: () => { _showQuickForm = true; _editingIndicator = null; renderIndicators() } }, '+ 첫 번째 지표 추가')
        )
      )
      return wrapper
    }

    groups.forEach(g => {
      const inds = filtered.filter(i => i.group_id === g.id)
      if (!inds.length) return
      const groupActive = inds.filter(i => i.is_active !== false).length
      wrapper.append(
        el('div', { className: 'card', style: 'padding:0;margin-bottom:12px;overflow:hidden' },
          el('div', { style: 'display:flex;align-items:center;gap:10px;padding:12px 16px;background:linear-gradient(135deg,#f8f6ff,#f0f0ff);border-bottom:2px solid #e0d8f0' },
            el('span', { style: 'font-size:18px' }, _selectedAuthority === 'ECOVADIS' ? '🌿' : _selectedAuthority === 'KSSB' ? '📜' : _selectedAuthority === 'KCGS' ? '🏢' : _selectedAuthority === 'NICE' ? '📊' : '📋'),
            el('h4', { style: 'margin:0;font-size:14px;color:#2c3e50;font-weight:700' }, Indicator.getGroupDisplayName(g)),
            el('span', { style: 'background:#7C3AED;color:#fff;font-size:11px;padding:2px 8px;border-radius:99px;font-weight:600' }, `${groupActive}/${inds.length}`)
          ),
          el('div', { style: 'padding:12px;display:grid;grid-template-columns:repeat(auto-fill,minmax(320px,1fr));gap:10px;background:#fafafa' },
            ...inds.map(ind => renderIndicatorCard(ind))
          )
        )
      )
    })

    return wrapper
  }

  function renderIndicatorCard(ind) {
    const pillarColor = ind.pillar === 'POLICY' ? '#7C3AED' : ind.pillar === 'ACTION' ? '#3B82F6' : ind.pillar === 'RESULT' ? '#10B981' : ind.pillar === 'GOVERNANCE' ? '#F59E0B' : ind.pillar === 'STRATEGY' ? '#EC4899' : ind.pillar === 'RISK_MGMT' ? '#EF4444' : '#6366F1'
    const isSelected = _selectedIndicators.has(ind.id)
    return el('div', { style: `background:#fff;border-radius:10px;padding:14px;box-shadow:0 2px 8px rgba(0,0,0,.06);border-left:4px solid ${ind.is_active === false ? '#ccc' : pillarColor};${ind.is_active === false ? 'opacity:.5' : ''}${isSelected ? ';outline:2px solid #7C3AED;outline-offset:1px' : ''};cursor:pointer`, onClick: (e) => { if (e.target.tagName === 'BUTTON' || e.target.tagName === 'INPUT' || e.target.tagName === 'SELECT') return; _editingIndicator = ind.id; _showQuickForm = true; renderIndicators() } },
      el('div', { style: 'display:flex;justify-content:space-between;align-items:flex-start;margin-bottom:6px' },
        el('div', { style: 'flex:1' },
          el('div', { style: 'display:flex;align-items:center;gap:6px;margin-bottom:4px' },
            el('input', { type: 'checkbox', checked: isSelected, onChange: (e) => { e.stopPropagation(); if (isSelected) _selectedIndicators.delete(ind.id); else _selectedIndicators.add(ind.id); renderIndicators() }, onClick: (e) => e.stopPropagation(), style: 'cursor:pointer;margin:0' }),
            el('span', { style: 'font-family:monospace;font-size:11px;font-weight:700;color:#7C3AED;background:#f3f0ff;padding:2px 6px;border-radius:4px' }, ind.indicator_code),
            el('span', { style: 'font-size:10px;padding:2px 6px;border-radius:4px;background:' + (ind.pillar === 'POLICY' ? '#f3e8ff;color:#7C3AED' : ind.pillar === 'ACTION' ? '#eff6ff;color:#3B82F6' : ind.pillar === 'RESULT' ? '#ecfdf5;color:#10B981' : '#fef3c7;color:#D97706') }, ind.pillar ? Indicator.getPillarName(ind.pillar) : '-')
          ),
          el('div', { style: 'font-size:13px;font-weight:600;color:#1a1a2e;line-height:1.4' }, Indicator.getDisplayName(ind))
        ),
        el('div', { style: 'display:flex;gap:4px' },
          el('button', { className: 'btn btn-sm btn-secondary', title: '수정', onClick: (e) => { e.stopPropagation(); _editingIndicator = ind.id; _showQuickForm = true; renderIndicators() } }, '✏'),
          el('button', { className: 'btn btn-sm', title: ind.is_active !== false ? '비활성화' : '활성화', style: ind.is_active !== false ? 'background:#f0fff4;color:#10B981' : 'background:#fff5f5;color:#e74c3c', onClick: (e) => { e.stopPropagation(); Indicator.toggleActive(ind.id); renderIndicators() } }, ind.is_active !== false ? '✓' : '✗')
        )
      ),
      el('div', { style: 'display:flex;gap:6px;font-size:11px;color:#888;flex-wrap:wrap' },
        ind.dept_code ? el('span', { style: 'background:#f0f0f0;padding:2px 6px;border-radius:4px' }, ind.dept_code) : null,
        ind.review_cycle ? el('span', { style: 'background:#f0f0f0;padding:2px 6px;border-radius:4px' }, ind.review_cycle === 'annual' ? '매년' : ind.review_cycle === 'semi_annual' ? '반기' : ind.review_cycle === 'quarterly' ? '분기' : '매월') : null,
        ind.scope2_split_required ? el('span', { style: 'background:#fef3c7;padding:2px 6px;border-radius:4px;color:#D97706;font-weight:600' }, '🌍 Scope2') : null
      )
    )
  }

  function renderQuickIndicatorForm() {
    const isEdit = _editingIndicator != null
    const ind = isEdit ? Store.getIndicators().find(i => i.id === _editingIndicator) : null
    const groups = Indicator.getGroups(_selectedAuthority)
    const pillarOptions = Indicator.getPillarOptions(_selectedAuthority)
    const depts = Store.getDepartments().filter(d => d.is_active !== false)

    const nameInput = el('input', { value: ind?.indicator_name ?? '', required: true, placeholder: '지표 이름을 입력하세요', style: 'font-size:13px;padding:7px 10px;border:1px solid #ddd;border-radius:6px;width:100%' })
    const pillarSel = el('select', { style: 'font-size:13px;padding:7px 10px;border:1px solid #ddd;border-radius:6px;width:100%' },
      el('option', { value: '' }, '-- 필러 선택 --'),
      ...pillarOptions.map(p => el('option', { value: p, selected: ind?.pillar === p }, Indicator.getPillarName(p)))
    )
    const groupSel = el('select', { style: 'font-size:13px;padding:7px 10px;border:1px solid #ddd;border-radius:6px;width:100%' },
      el('option', { value: '' }, '-- 그룹 선택 --'),
      ...groups.map(g => el('option', { value: g.id, selected: ind?.group_id === g.id }, g.group_name))
    )
    const deptSel = el('select', { style: 'font-size:13px;padding:7px 10px;border:1px solid #ddd;border-radius:6px;width:100%' },
      el('option', { value: '' }, '-- 담당부서 --'),
      ...depts.map(d => el('option', { value: d.dept_code, selected: ind?.dept_code === d.dept_code }, d.dept_name))
    )
    const cycleSel = el('select', { style: 'font-size:13px;padding:7px 10px;border:1px solid #ddd;border-radius:6px;width:100%' },
      [['annual', '매년'], ['semi_annual', '반기'], ['quarterly', '분기'], ['monthly', '매월']].map(([v, l]) => el('option', { value: v, selected: ind?.review_cycle === v }, l))
    )
    const scope2Check = el('input', { type: 'checkbox', checked: ind?.scope2_split_required === true, style: 'cursor:pointer' })

    const card = el('div', { className: 'card', style: 'border-left:3px solid #7C3AED;background:#fafbff;margin-bottom:12px' },
      el('div', { style: 'padding:12px 16px;display:flex;justify-content:space-between;align-items:center;border-bottom:1px solid #e0d8f0' },
        el('h4', { style: 'margin:0;font-size:14px' }, isEdit ? `✏ 지표 수정: ${ind?.indicator_code || ''}` : '+ 새 지표 추가'),
        el('button', { className: 'btn btn-sm', onClick: () => { _showQuickForm = false; _editingIndicator = null; renderIndicators() } }, '✕')
      ),
      el('div', { style: 'padding:16px;display:grid;grid-template-columns:1fr 1fr;gap:10px' },
        el('div', { style: 'grid-column:1/3' },
          el('label', { style: 'font-size:12px;font-weight:600;color:#555;display:block;margin-bottom:3px' }, '지표명 *'),
          nameInput
        ),
        el('div', {},
          el('label', { style: 'font-size:12px;font-weight:600;color:#555;display:block;margin-bottom:3px' }, '필러 유형'),
          pillarSel
        ),
        el('div', {},
          el('label', { style: 'font-size:12px;font-weight:600;color:#555;display:block;margin-bottom:3px' }, '그룹'),
          groupSel
        ),
        el('div', {},
          el('label', { style: 'font-size:12px;font-weight:600;color:#555;display:block;margin-bottom:3px' }, '담당부서'),
          deptSel
        ),
        el('div', {},
          el('label', { style: 'font-size:12px;font-weight:600;color:#555;display:block;margin-bottom:3px' }, '검토주기'),
          cycleSel
        ),
        el('div', { style: 'grid-column:1/3;display:flex;align-items:center;gap:8px' },
          scope2Check,
          el('label', { style: 'font-size:12px;color:#555;cursor:pointer' }, '🌍 Scope2 이중보고 대상 (location-based / market-based)')
        )
      ),
      el('div', { style: 'padding:8px 16px 12px;display:flex;gap:6px;justify-content:flex-end' },
        el('button', { className: 'btn btn-secondary btn-sm', onClick: () => { _showQuickForm = false; _editingIndicator = null; renderIndicators() } }, '취소'),
        el('button', { className: 'btn btn-primary btn-sm', onClick: () => {
          if (!nameInput.value.trim()) return alert('지표명을 입력하세요')
          const data = {
            authority_code: _selectedAuthority,
            indicator_name: nameInput.value.trim(),
            pillar: pillarSel.value || null,
            group_id: parseInt(groupSel.value) || groups[0]?.id,
            dept_code: deptSel.value,
            review_cycle: cycleSel.value,
            scope2_split_required: scope2Check.checked,
            is_active: true
          }
          if (isEdit && ind) Store.updateIndicator(ind.id, data)
          else Store.addIndicator(data)
          _showQuickForm = false; _editingIndicator = null; renderIndicators()
        } }, isEdit ? '💾 저장' : '+ 추가')
      )
    )
    return card
  }

  function openImportTemplate() {
    const templates = {
      'ECOVADIS': { name: 'EcoVadis 18개 골격', count: 18, desc: '환경(5), 인권/사회(4), 윤리(4), 지속가능조달(4), 360도(1)' },
      'KSSB': { name: 'KSSB 한국형 기준', count: 8, desc: '거버넌스/전략/리스크관리/측정 (개인/조직 각 4개)' },
      'KCGS': { name: 'KCGS 통합보고 기준', count: 3, desc: '지배구조/사회/환경' },
      'NICE': { name: 'NICE ESG 평가', count: 3, desc: '환경/사회/지배구조' },
      'K-ESG': { name: 'K-ESG 기업환경책임', count: 6, desc: 'E1/E2/S1/S2/G1/G2' }
    }
    const form = el('div', { style: 'display:flex;flex-direction:column;gap:12px' },
      el('p', { style: 'margin:0;font-size:13px;color:#666' }, '기준 템플릿에서 표준 지표를 가져옵니다. 이미 동일한 코드의 지표가 있으면 건너뜁니다.'),
      ...Object.entries(templates).map(([code, t]) => {
        const existing = Store.getIndicators().filter(i => i.authority_code === code).length
        return el('div', { style: `padding:12px;border:1px solid ${existing > 0 ? '#ddd' : '#7C3AED33'};border-radius:8px;background:${existing > 0 ? '#f9f9f9' : '#fafbff'};display:flex;justify-content:space-between;align-items:center` },
          el('div', {},
            el('div', { style: 'font-weight:600;font-size:13px' }, `${Indicator.getAuthorityName(code)} — ${t.name}`),
            el('div', { style: 'font-size:12px;color:#888;margin-top:2px' }, t.desc),
            el('div', { style: 'font-size:11px;color:#888;margin-top:4px' }, `현재 ${existing}개 지표 등록됨`)
          ),
          el('button', { className: `btn btn-sm ${existing > 0 ? 'btn-secondary' : 'btn-primary'}`, onClick: () => {
            if (existing > 0 && !confirm(`${Indicator.getAuthorityName(code)} 템플릿을 다시 가져오시겠습니까? 기존과 중복될 수 있습니다.`)) return
            let count = 0
            if (code === 'ECOVADIS') { /* EcoVadis는 이미 시드에 포함 */ alert('EcoVadis 18개 골격은 이미 기본 포함되어 있습니다.'); return }
            _selectedAuthority = code
            closeModal(); renderIndicators()
          } }, existing > 0 ? '확인됨' : '가져오기')
        )
      })
    )
    modal('📥 템플릿에서 지표 가져오기', form)
    document.getElementById('modal-save').style.display = 'none'
  }

  // ==================== 증빙 관리 ====================
  let _evidenceAssId = null

  function renderIndicatorMapping() {
    const mappings = Store.getIndicatorMappings()
    const allIndicators = Store.getIndicators()
    const container = el('div', { className: 'card' },
      el('div', { className: 'card-header' },
        el('h3', {}, `지표 매핑 관리 (${mappings.length}개 매핑)`),
        el('button', { className: 'btn btn-primary', onClick: openAddMapping }, '+ 매핑 추가')
      )
    )
    if (!mappings.length) {
      container.append(el('p', { style: 'padding:20px;color:#999;text-align:center' }, '등록된 매핑이 없습니다. 기관 간 지표 매핑을 추가하세요.'))
    } else {
      const rows = mappings.map(m => {
        const srcInd = allIndicators.find(i => i.id === m.source_indicator_id)
        const tgtInd = allIndicators.find(i => i.id === m.target_indicator_id)
        const confColors = { high: '#27ae60', medium: '#f39c12', low: '#e74c3c' }
        const confLabels = { high: '높음', medium: '보통', low: '낮음' }
        const typeLabels = { direct: '직접', expanded: '확장', indirect: '간접' }
        return el('tr', {},
          el('td', { style: 'font-size:12px' }, srcInd ? `${Indicator.getAuthorityName(srcInd.authority_code)} - ${srcInd.indicator_code}` : '?'),
          el('td', { style: 'font-size:12px' }, srcInd ? Indicator.getDisplayName(srcInd) : '?'),
          el('td', { style: 'text-align:center;font-size:16px;color:#7C3AED' }, '→'),
          el('td', { style: 'font-size:12px' }, tgtInd ? `${Indicator.getAuthorityName(tgtInd.authority_code)} - ${tgtInd.indicator_code}` : '?'),
          el('td', { style: 'font-size:12px' }, tgtInd ? Indicator.getDisplayName(tgtInd) : '?'),
          el('td', { style: 'text-align:center;font-size:12px' }, typeLabels[m.mapping_type] || m.mapping_type),
          el('td', { style: 'text-align:center' },
            el('span', { style: `padding:2px 8px;border-radius:99px;font-size:11px;font-weight:600;background:${confColors[m.confidence] || '#ccc'}20;color:${confColors[m.confidence] || '#888'}` }, confLabels[m.confidence] || m.confidence || '-')
          ),
          el('td', { style: 'text-align:center' },
            el('button', { className: 'btn btn-sm btn-danger', onClick: () => { if (confirm('매핑을 삭제하시겠습니까?')) { Store.deleteIndicatorMapping(m.id); renderIndicators() } } }, '삭제')
          )
        )
      })
      container.append(
        el('table', { style: 'width:100%;border-collapse:collapse;font-size:12px' },
          el('thead', {}, el('tr', {},
            el('th', { style: 'padding:8px;text-align:left;border-bottom:2px solid #e0d8f0' }, '원본 기관-코드'),
            el('th', { style: 'padding:8px;text-align:left;border-bottom:2px solid #e0d8f0' }, '원본 지표명'),
            el('th', { style: 'padding:8px;text-align:center;border-bottom:2px solid #e0d8f0;width:40px' }, ''),
            el('th', { style: 'padding:8px;text-align:left;border-bottom:2px solid #e0d8f0' }, '대상 기관-코드'),
            el('th', { style: 'padding:8px;text-align:left;border-bottom:2px solid #e0d8f0' }, '대상 지표명'),
            el('th', { style: 'padding:8px;text-align:center;border-bottom:2px solid #e0d8f0' }, '유형'),
            el('th', { style: 'padding:8px;text-align:center;border-bottom:2px solid #e0d8f0' }, '신뢰도'),
            el('th', { style: 'padding:8px;text-align:center;border-bottom:2px solid #e0d8f0' }, '관리')
          )),
          el('tbody', {}, ...rows)
        )
      )
    }
    return container
  }

  function openAddMapping() {
    const form = el('form', { onSubmit: e => e.preventDefault() })
    const allIndicators = Store.getIndicators().filter(i => i.is_active !== false)
    const srcAuth = el('select', { onChange: () => updateMappingIndicators() },
      ['ECOVADIS', 'KSSB', 'KCGS', 'NICE', 'K-ESG'].map(code => el('option', { value: code }, Indicator.getAuthorityName(code)))
    )
    const srcInd = el('select', { id: 'mapping-src-ind' })
    const tgtAuth = el('select', { onChange: () => updateMappingIndicators() },
      ['ECOVADIS', 'KSSB', 'KCGS', 'NICE', 'K-ESG'].map(code => el('option', { value: code }, Indicator.getAuthorityName(code)))
    )
    const tgtInd = el('select', { id: 'mapping-tgt-ind' })
    const mapType = el('select', {},
      el('option', { value: 'direct' }, '직접 (direct)'),
      el('option', { value: 'expanded' }, '확장 (expanded)'),
      el('option', { value: 'indirect' }, '간접 (indirect)')
    )
    const confidence = el('select', {},
      el('option', { value: 'high' }, '높음'),
      el('option', { value: 'medium' }, '보통'),
      el('option', { value: 'low' }, '낮음')
    )
    function updateMappingIndicators() {
      const srcList = allIndicators.filter(i => i.authority_code === srcAuth.value)
      const tgtList = allIndicators.filter(i => i.authority_code === tgtAuth.value)
      srcInd.innerHTML = ''
      tgtInd.innerHTML = ''
      srcList.forEach(i => srcInd.append(el('option', { value: i.id }, `${i.indicator_code} - ${Indicator.getDisplayName(i)}`)))
      tgtList.forEach(i => tgtInd.append(el('option', { value: i.id }, `${i.indicator_code} - ${Indicator.getDisplayName(i)}`)))
    }
    updateMappingIndicators()
    form.append(
      el('div', { style: 'display:grid;grid-template-columns:1fr auto 1fr;gap:8px;align-items:end' },
        el('div', { className: 'form-group' }, el('label', {}, '원본 기관'), srcAuth, el('label', { style: 'margin-top:6px;display:block' }, '원본 지표'), srcInd),
        el('div', { style: 'padding-bottom:8px;font-size:20px;color:#7C3AED' }, '→'),
        el('div', { className: 'form-group' }, el('label', {}, '대상 기관'), tgtAuth, el('label', { style: 'margin-top:6px;display:block' }, '대상 지표'), tgtInd)
      ),
      el('div', { style: 'display:grid;grid-template-columns:1fr 1fr;gap:8px' },
        el('div', { className: 'form-group' }, el('label', {}, '매핑 유형'), mapType),
        el('div', { className: 'form-group' }, el('label', {}, '신뢰도'), confidence)
      )
    )
    modal('지표 매핑 추가', form)
    document.getElementById('modal-save').onclick = () => {
      if (!srcInd.value || !tgtInd.value) return alert('원본과 대상 지표를 모두 선택하세요')
      Store.addIndicatorMapping({
        source_authority: srcAuth.value,
        source_indicator_id: parseInt(srcInd.value),
        target_authority: tgtAuth.value,
        target_indicator_id: parseInt(tgtInd.value),
        mapping_type: mapType.value,
        confidence: confidence.value
      })
      closeModal(); renderIndicators()
    }
  }

  // Indicator functions now inline in renderIndicatorListInline

  function renderEvidenceMgmt() {
    const c = document.getElementById('page-evidence')
    if (!c) return
    const assessments = Store.getAssessments() || []
    c.innerHTML = ''
    if (!assessments.length) {
      c.append(
        el('div', { className: 'card', style: 'text-align:center;padding:40px 20px' },
          el('div', { style: 'font-size:36px;margin-bottom:12px' }, '📎'),
          el('h3', { style: 'margin:0 0 8px' }, '증빙을 관리하려면 평가를 먼저 생성하세요'),
          el('p', { style: 'margin:0 0 16px;color:#888;font-size:13px' }, '증빙 문서는 평가별 55건까지 등록 가능합니다.'),
          el('button', { className: 'btn btn-primary', onClick: () => navigate('assessment') }, '+ 평가 생성하러 가기')
        )
      )
      return
    }
    _evidenceAssId = _evidenceAssId || assessments[0].id
    if (!assessments.find(a => a.id === _evidenceAssId)) _evidenceAssId = assessments[0].id
    const evidences = Evidence.getAll(_evidenceAssId)
    c.append(
      el('div', { className: 'card' },
        el('div', { className: 'card-header' },
          el('h3', {}, '증빙 관리'),
          el('div', { style: 'display:flex;gap:8px;align-items:center' },
            el('select', { id: 'evAssSelect', onChange: () => { _evidenceAssId = parseInt(document.getElementById('evAssSelect').value); renderEvidenceMgmt() } },
              ...assessments.map(a => el('option', { value: a.id, selected: a.id === _evidenceAssId }, a.title))
            ),
            el('button', { className: 'btn btn-primary', onClick: openAddEvidence }, '+ 증빙 추가')
          )
        ),
        evidences.length ? sortableTable('evidences', [
          { label: '제목', value: ev => { const c = el('span', {}); const files = Store.getEvidenceFiles(ev.id); c.append(ev.title, files.length > 0 ? el('span', { style: 'color:#7C3AED;font-size:11px;margin-left:4px' }, `[${files.length}개 파일]`) : ev.file_data ? el('a', { href: ev.file_data, download: ev.file_name, style: 'color:#7C3AED;text-decoration:none;font-size:11px;margin-left:4px' }, `📎${ev.file_name}`) : null); return c } },
          { label: '유형', value: ev => el('span', {}, { pdf: 'PDF 문서', xlsx: 'Excel', docx: 'Word', img: '이미지', etc: '기타' }[ev.file_type] || ev.file_type || '-'), align: 'center' },
          { label: '상태', value: ev => evidenceStatusBadge(ev.status), align: 'center' },
          { label: '태그', value: ev => { const tags = Evidence.getTags(ev.id); return tags.map(t => { const ind = Store.getIndicators().find(i => i.id === t.indicator_id); return ind ? ind.indicator_code : '?' }).join(', ') || '-' } }
        ], evidences, {
          bulkDelete: id => Store.deleteEvidence(id),
          actions: ev => [
            el('button', { className: 'btn btn-sm btn-primary', style: { marginRight: 4 }, onClick: () => editEvidence(ev.id) }, '수정'),
            el('button', { className: 'btn btn-sm btn-danger', onClick: () => { Store.deleteEvidence(ev.id); renderEvidenceMgmt() } }, '삭제')
          ]
        }) : el('p', { style: 'padding:16px;color:#999' }, '등록된 증빙이 없습니다.')
      )
    )
  }

  function openAddEvidence() { createEvidenceModal() }
  function editEvidence(id) { const ev = Store.getEvidences().find(x => x.id === id); if (ev) createEvidenceModal(ev) }

  function createEvidenceModal(ev) {
    const isEdit = !!ev
    if (!isEdit && !Evidence.canAddMore(_evidenceAssId)) {
      alert(`증빙 문서는 평가당 ${55}개까지 등록 가능합니다.\n기존 증빙을 삭제하거나 우선순위 태깅을 활용해주세요.`)
      return
    }
    const existingTags = ev ? Evidence.getTags(ev.id).map(t => t.indicator_id) : []
    const existingFiles = ev ? Store.getEvidenceFiles(ev.id) : []
    const form = el('form', { onSubmit: e => e.preventDefault() })
    const title = el('input', { value: ev?.title ?? '' })
    const fileTypeLabels = { pdf: 'PDF 문서', xlsx: 'Excel', docx: 'Word', img: '이미지', etc: '기타' }
    const fileType = el('select', {}, ['pdf', 'xlsx', 'docx', 'img', 'etc'].map(t => el('option', { value: t, selected: ev?.file_type === t }, fileTypeLabels[t])))
    const status = el('select', {}, ['self', 'internal_reviewed', 'externally_verified'].map(s => el('option', { value: s, selected: ev?.status === s }, Evidence.getStatusLabel(s))))
    const expiryDate = el('input', { type: 'date', value: ev?.expiry_date ?? '' })
    const sensitiveCheck = el('input', { type: 'checkbox', checked: ev?.contains_sensitive_data === true })
    const indicators = Store.getIndicators().filter(i => i.is_active !== false)
    const fileInput = el('input', { type: 'file', multiple: true, style: 'margin-top:4px' })
    const fileListContainer = el('div', { style: 'margin-top:6px' })
    window._pendingFiles = []

    if (existingFiles.length) {
      existingFiles.forEach(f => {
        const row = el('div', { style: 'display:flex;align-items:center;gap:6px;padding:4px 8px;background:#f8f9fa;border-radius:6px;margin-bottom:4px;font-size:12px' },
          el('span', {}, '📎 ' + f.file_name),
          el('span', { style: 'color:#999' }, `(${(f.file_size / 1024).toFixed(1)}KB)`),
          el('button', { type: 'button', style: 'background:#e74c3c;color:#fff;border:none;border-radius:4px;padding:2px 8px;cursor:pointer;font-size:11px', onClick: () => { Store.deleteEvidenceFile(f.id); row.remove() } }, '×')
        )
        fileListContainer.append(row)
      })
    }

    fileInput.onchange = () => {
      const files = Array.from(fileInput.files || [])
      files.forEach(file => {
        if (file.size > 10 * 1024 * 1024) { alert(file.name + '은 10MB를 초과합니다.'); return }
        window._pendingFiles.push(file)
        const row = el('div', { style: 'display:flex;align-items:center;gap:6px;padding:4px 8px;background:#f0fff0;border-radius:6px;margin-bottom:4px;font-size:12px' },
          el('span', {}, '📎 ' + file.name),
          el('span', { style: 'color:#999' }, `(${(file.size / 1024).toFixed(1)}KB)`),
          el('button', { type: 'button', style: 'background:#e74c3c;color:#fff;border:none;border-radius:4px;padding:2px 8px;cursor:pointer;font-size:11px', onClick: () => { window._pendingFiles = window._pendingFiles.filter(f => f !== file); row.remove() } }, '×')
        )
        fileListContainer.append(row)
      })
      fileInput.value = ''
    }

    const tagContainer = el('div', { style: 'margin-top:8px' })

    window._tagValues = existingTags.slice()

    function addTagRow(val) {
      const row = el('div', { style: 'display:flex;gap:6px;margin-bottom:6px' },
        el('select', { style: 'flex:1' },
          el('option', { value: '' }, '=== 항목 선택 ==='),
          ...indicators.map(ind => el('option', { value: ind.id, selected: ind.id === val }, Indicator.getNameAndCode(ind)))
        ),
        el('button', { type: 'button', style: 'background:#e74c3c;color:#fff;border:none;border-radius:6px;padding:4px 10px;cursor:pointer;font-size:12px' }, '×')
      )
      const sel = row.querySelector('select')
      const delBtn = row.lastChild
      sel.onchange = () => { _tagValues = _tagValues.filter(v => v !== val); _tagValues.push(parseInt(sel.value)) }
      delBtn.onclick = () => { row.remove(); _tagValues = _tagValues.filter(v => v !== parseInt(sel.value)) }
      tagContainer.append(row)
    }

    if (existingTags.length) existingTags.forEach(v => addTagRow(v))
    else addTagRow(null)

    const addBtn = el('button', { type: 'button', className: 'btn btn-sm btn-secondary', style: 'margin-top:4px' }, '+ 항목 추가')
    addBtn.onclick = () => addTagRow(null)
    tagContainer.append(addBtn)

    form.append(el('label', {}, '제목', title), el('label', {}, '파일 유형', fileType), el('label', {}, '파일 첨부 (다중 선택 가능)', fileInput, fileListContainer), el('label', {}, '상태', status), el('label', {}, '유효기간', expiryDate), el('label', { style: 'display:flex;align-items:center;gap:8px;margin-top:8px' }, sensitiveCheck, '민감정보 포함 (임금·인사 등)'), el('label', { style: 'margin-top:8px;font-weight:500' }, '연결 항목'), tagContainer)
    modal(isEdit ? '증빙 수정' : '증빙 추가', form)
    document.getElementById('modal-save').onclick = function save() {
      const pendingFiles = window._pendingFiles || []
      const data = { assessment_id: _evidenceAssId, title: title.value, file_type: fileType.value, status: status.value }
      if (pendingFiles.length > 0) {
        let loaded = 0
        const results = []
        pendingFiles.forEach(file => {
          const reader = new FileReader()
          reader.onload = function(e) {
            results.push({ file_name: file.name, file_data: e.target.result, file_size: file.size, mime_type: file.type })
            loaded++
            if (loaded === pendingFiles.length) {
              data.file_name = results[0].file_name
              data.file_data = results[0].file_data
              data.file_size = results[0].file_size
              finalizeSave(data, results)
            }
          }
          reader.readAsDataURL(file)
        })
      } else {
        finalizeSave(data, [])
      }
    }
    function finalizeSave(data, newFiles) {
      data.expiry_date = expiryDate.value
      data.contains_sensitive_data = sensitiveCheck.checked
      let evidenceId
      if (isEdit) {
        Store.updateEvidence(ev.id, data)
        existingTags.forEach(tid => Evidence.untag(ev.id, tid))
        evidenceId = ev.id
      } else {
        const e = Evidence.add(data)
        evidenceId = e.id
      }
      _tagValues.forEach(tid => { if (tid) Evidence.tag(evidenceId, parseInt(tid)) })
      newFiles.forEach(f => {
        Store.addEvidenceFile({ evidence_id: evidenceId, file_name: f.file_name, file_path: f.file_data, file_size: f.file_size, mime_type: f.mime_type })
      })
      closeModal(); renderEvidenceMgmt()
    }
  }

  // ==================== 온실가스 ====================
  let _ghgAssId = null
  function renderGHG() {
    const c = document.getElementById('page-ghg')
    if (!c) return
    const assessments = Store.getAssessments() || []
    c.innerHTML = ''
    if (!assessments.length) {
      c.append(
        el('div', { className: 'card', style: 'text-align:center;padding:40px 20px' },
          el('div', { style: 'font-size:36px;margin-bottom:12px' }, '🌍'),
          el('h3', { style: 'margin:0 0 8px' }, 'GHG 온실가스 관리'),
          el('p', { style: 'margin:0 0 16px;color:#888;font-size:13px' }, 'GHG 데이터 입력을 위해 먼저 평가를 생성하세요.'),
          el('button', { className: 'btn btn-primary', onClick: () => navigate('assessment') }, '+ 평가 생성하러 가기')
        )
      )
      return
    }
    _ghgAssId = _ghgAssId || assessments[0].id
    if (!assessments.find(a => a.id === _ghgAssId)) _ghgAssId = assessments[0].id
    const summary = GHG.getSummary(_ghgAssId)
    const activities = Store.getGHGActivities().filter(a => a.assessment_id === _ghgAssId)
    c.append(
      el('div', { className: 'card' },
        el('div', { className: 'card-header' },
          el('h3', {}, '온실가스 관리'),
          el('div', { style: 'display:flex;gap:8px' },
            el('select', { id: 'ghgAssSelect', onChange: () => { _ghgAssId = parseInt(document.getElementById('ghgAssSelect').value); renderGHG() } },
              ...assessments.map(a => el('option', { value: a.id, selected: a.id === _ghgAssId }, a.title))
            ),
            el('button', { className: 'btn btn-primary', onClick: openAddGHG }, '+ 활동자료 입력')
          )
        ),
        Object.keys(summary).length ? el('div', { style: 'padding:12px 20px;background:#f8f9fa;border-bottom:1px solid #eee;font-size:13px' },
          el('pre', { style: 'margin:0;white-space:pre-wrap' }, GHG.formatSummary(summary))
        ) : null,
        activities.length ? sortableTable('ghg', [
          { label: '유형', value: a => (ENERGY_LABELS[a.energy_type] || a.energy_type) + ' (' + a.energy_type + ')' },
          { label: 'Scope', value: a => `Scope ${a.scope}` },
          { label: '구분', value: a => a.scope2_method === 'location-based' ? '위치기준' : a.scope2_method === 'market-based' ? '시장기준' : '-' },
          { label: '값', value: a => `${a.value} ${a.unit}` },
          { label: 'tCO2eq', value: a => a.co2eq ? a.co2eq.toFixed(4) : '-' }
        ], activities, {
          bulkDelete: id => Store.deleteGHGActivity(id),
          actions: a => [
            el('button', { className: 'btn btn-sm btn-danger', onClick: () => { Store.deleteGHGActivity(a.id); renderGHG() } }, '삭제')
          ]
        }) : el('p', { style: 'padding:16px;color:#999' }, '등록된 활동자료가 없습니다.')
      )
    )
  }

  function openAddGHG() {
    const form = el('form', { onSubmit: e => e.preventDefault() })
    const energyType = el('select', {}, ['electricity', 'natural_gas', 'diesel', 'gasoline', 'water', 'waste', 'other'].map(t => el('option', { value: t }, ENERGY_LABELS[t] + ' (' + t + ')')))
    const scope = el('select', { onChange: () => { s2m.style.display = scope.value === '2' ? 'block' : 'none' } },
      el('option', { value: '1' }, 'Scope 1 (직접)'), el('option', { value: '2' }, 'Scope 2 (에너지 간접)'), el('option', { value: '3' }, 'Scope 3 (가치사슬)'))
    const s2m = el('select', { style: 'display:none' },
      el('option', { value: 'location-based' }, '위치기준 (Location-based)'), el('option', { value: 'market-based' }, '시장기준 (Market-based)'))
    const value = el('input', { type: 'number', step: '0.01', required: true })
    const unit = el('input', { value: 'kWh', required: true })
    const ps = el('input', { type: 'date', required: true })
    const pe = el('input', { type: 'date', required: true })
    form.append(el('label', {}, '에너지 유형', energyType), el('label', {}, 'Scope', scope), el('label', {}, s2m), el('label', {}, '활동량', value), el('label', {}, '단위', unit), el('label', {}, '시작일', ps), el('label', {}, '종료일', pe))
    modal('온실가스 활동자료 입력', form)
    document.getElementById('modal-save').onclick = function save() {
      GHG.addActivity({ assessment_id: _ghgAssId, energy_type: energyType.value, scope: parseInt(scope.value), scope2_method: scope.value === '2' ? s2m.value : null, value: parseFloat(value.value), unit: unit.value, period_start: ps.value, period_end: pe.value })
      closeModal(); renderGHG()
    }
  }

  // ==================== 협력사 리스크 ====================
  let _supplierTab = 'list'

  function renderSupplier() {
    const c = document.getElementById('page-supplier')
    c.innerHTML = ''
    c.append(
      el('div', { style: 'display:flex;gap:8px;margin-bottom:12px' },
        el('button', { className: 'btn' + (_supplierTab === 'list' ? ' btn-primary' : ''), onClick: () => { _supplierTab = 'list'; renderSupplier() } }, '📋 협력사 목록'),
        el('button', { className: 'btn' + (_supplierTab === 'vsme' ? ' btn-primary' : ''), onClick: () => { _supplierTab = 'vsme'; renderSupplier() } }, '📝 VSME 자가진단')
      ),
      _supplierTab === 'list' ? renderSupplierList() : renderVSMEPanel()
    )
  }

  function renderSupplierList() {
    const suppliers = Supplier.getAll()
    const summary = Supplier.getSummary()
    const container = el('div', {})

    container.append(
      el('div', { style: 'display:grid;grid-template-columns:repeat(auto-fit,minmax(160px,1fr));gap:12px;margin-bottom:16px' },
        el('div', { style: 'background:#fff;border-radius:10px;padding:16px;box-shadow:0 1px 3px rgba(0,0,0,.1)' },
          el('div', { style: 'font-size:12px;color:#888' }, '총 협력사'),
          el('div', { style: 'font-size:28px;font-weight:700' }, summary.total)
        ),
        ...Supplier.RISK_GRADES.map(g => el('div', { style: `background:#fff;border-radius:10px;padding:16px;box-shadow:0 1px 3px rgba(0,0,0,.1);border-left:4px solid ${g.color}` },
          el('div', { style: 'font-size:12px;color:#888' }, `${g.grade}등급 (${g.label})`),
          el('div', { style: 'font-size:28px;font-weight:700;color:' + g.color }, summary.riskCounts[g.grade] || 0)
        )),
        el('div', { style: 'background:#fff;border-radius:10px;padding:16px;box-shadow:0 1px 3px rgba(0,0,0,.1);border-left:4px solid #ccc' },
          el('div', { style: 'font-size:12px;color:#888' }, '미진단'),
          el('div', { style: 'font-size:28px;font-weight:700;color:#999' }, summary.riskCounts.unscored || 0)
        )
      ),
      el('div', { className: 'card' },
        el('div', { className: 'card-header' },
          el('h3', {}, '협력사 목록'),
          el('button', { className: 'btn btn-primary', onClick: openAddSupplier }, '+ 협력사 추가')
        ),
        suppliers.length ? sortableTable('suppliers', [
          { label: '회사명', key: 'name', value: s => s.name || '-' },
          { label: '업종', key: 'industry', value: s => s.industry || '-' },
          { label: '대표자', key: 'ceo', value: s => s.ceo || '-' },
          { label: '규모', key: 'employee_count', value: s => s.employee_count ? s.employee_count + '명' : '-', align: 'center' },
          { label: '리스크등급', value: s => {
            if (!s.last_vsme_grade) return el('span', { style: 'color:#ccc' }, '미진단')
            const g = Supplier.getGrade(s.last_vsme_score)
            return el('span', { style: `background:${g.color};color:#fff;padding:2px 10px;border-radius:10px;font-size:11px;font-weight:600` }, `${s.last_vsme_grade}등급 (${s.last_vsme_score}점)`)
          }, align: 'center' },
          { label: '최근 진단', key: 'last_vsme_date', value: s => s.last_vsme_date ? new Date(s.last_vsme_date).toLocaleDateString('ko-KR') : '-' }
        ], suppliers, {
          bulkDelete: id => Supplier.delete(id),
          actions: s => [
            el('button', { className: 'btn btn-sm btn-primary', style: { marginRight: 4 }, onClick: () => openVSMEForSupplier(s.id) }, '자가진단'),
            el('button', { className: 'btn btn-sm btn-secondary', style: { marginRight: 4 }, onClick: () => editSupplier(s.id) }, '수정'),
            el('button', { className: 'btn btn-sm btn-danger', onClick: () => { if (confirm('정말 삭제?')) { Supplier.delete(s.id); renderSupplier() } } }, '삭제')
          ]
        }) : el('p', { style: 'padding:20px;color:#999' }, '등록된 협력사가 없습니다.')
      )
    )
    return container
  }

  function openAddSupplier() { createSupplierModal() }
  function editSupplier(id) { const s = Supplier.getAll().find(x => x.id === id); if (s) createSupplierModal(s) }

  function createSupplierModal(s) {
    const isEdit = !!s
    const form = el('form', { onSubmit: e => e.preventDefault() })
    const name = el('input', { value: s?.name ?? '', required: true })
    const industry = el('input', { value: s?.industry ?? '' })
    const ceo = el('input', { value: s?.ceo ?? '' })
    const empCount = el('input', { type: 'number', value: s?.employee_count ?? '' })
    const revenue = el('input', { type: 'number', value: s?.revenue ?? '' })
    const phone = el('input', { value: s?.phone ?? '' })
    const email = el('input', { type: 'email', value: s?.email ?? '' })
    form.append(
      el('label', {}, '회사명 *', name),
      el('label', {}, '업종', industry),
      el('label', {}, '대표자', ceo),
      el('label', {}, '직원 수', empCount),
      el('label', {}, '매출(백만원)', revenue),
      el('label', {}, '연락처', phone),
      el('label', {}, '이메일', email)
    )
    modal(isEdit ? '협력사 수정' : '협력사 추가', form)
    document.getElementById('modal-save').onclick = () => {
      const data = { name: name.value, industry: industry.value, ceo: ceo.value, employee_count: parseInt(empCount.value) || null, revenue: parseFloat(revenue.value) || null, phone: phone.value, email: email.value }
      if (isEdit) Supplier.update(s.id, data)
      else Supplier.add(data)
      closeModal(); renderSupplier()
    }
  }

  function renderVSMEPanel() {
    const suppliers = Supplier.getAll()
    const container = el('div', { className: 'card' },
      el('div', { className: 'card-header' },
        el('h3', {}, 'VSME 자가진단'),
        el('div', { style: 'font-size:12px;color:#888' }, 'EcoVadis SP테마 + VSME 중소기업 자율보고 기준')
      )
    )
    if (!suppliers.length) {
      container.append(el('p', { style: 'padding:20px;color:#999' }, '먼저 협력사를 등록해주세요.'))
      return container
    }
    suppliers.forEach(s => {
      const latest = Supplier.getLatestVSME(s.id)
      const grade = latest ? Supplier.getGrade(latest.score) : null
      container.append(
        el('div', { style: 'padding:12px 16px;border-bottom:1px solid #f0f0f0;display:flex;align-items:center;justify-content:space-between' },
          el('div', {},
            el('div', { style: 'font-weight:600;font-size:14px' }, s.name),
            el('div', { style: 'font-size:12px;color:#888' }, latest ? `최근: ${latest.mode === 'basic' ? '기본' : '종합'} ${latest.score}점 ${latest.grade}등급 (${new Date(latest.assessed_at).toLocaleDateString('ko-KR')})` : '미진단')
          ),
          el('div', { style: 'display:flex;gap:6px' },
            el('button', { className: 'btn btn-sm btn-primary', onClick: () => openVSMEForSupplier(s.id) }, '자가진단 실시'),
            latest ? el('button', { className: 'btn btn-sm btn-secondary', onClick: () => showVSMEHistory(s.id) }, '이력') : null
          )
        )
      )
    })
    return container
  }

  function openVSMEForSupplier(supplierId) {
    const supplier = Supplier.getAll().find(s => s.id === supplierId)
    if (!supplier) return
    const form = el('div', {})
    const mode = el('select', { style: 'width:100%;padding:8px;border:1px solid #ddd;border-radius:6px;margin-bottom:12px' },
      el('option', { value: 'basic' }, '기본 모드 (12항목)'),
      el('option', { value: 'comprehensive' }, '종합 모드 (14항목)')
    )
    const questionContainer = el('div', {})
    function renderQuestions() {
      const checklist = Supplier.getVSMEChecklist(mode.value)
      questionContainer.innerHTML = ''
      checklist.forEach(q => {
        const row = el('div', { style: 'padding:8px 0;border-bottom:1px solid #f0f0f0' },
          el('div', { style: 'font-size:13px;margin-bottom:4px' }, `[${q.category}] ${q.question}`),
          el('div', { style: 'display:flex;gap:8px' },
            el('label', { style: 'font-size:12px;cursor:pointer' }, el('input', { type: 'radio', name: q.id, value: 'yes' }), ' 예'),
            el('label', { style: 'font-size:12px;cursor:pointer' }, el('input', { type: 'radio', name: q.id, value: 'no' }), ' 아니오'),
            el('label', { style: 'font-size:12px;cursor:pointer' }, el('input', { type: 'radio', name: q.id, value: 'na', checked: true }), ' 해당없음')
          )
        )
        questionContainer.append(row)
      })
    }
    mode.onchange = renderQuestions
    renderQuestions()
    form.append(mode, questionContainer)
    modal(`VSME 자가진단 - ${supplier.name}`, form)
    document.getElementById('modal-save').onclick = () => {
      const checklist = Supplier.getVSMEChecklist(mode.value)
      const answers = checklist.map(q => {
        const checked = form.querySelector(`input[name="${q.id}"]:checked`)
        return checked ? checked.value : 'na'
      })
      Supplier.submitVSME(supplierId, mode.value, answers)
      closeModal(); renderSupplier()
    }
  }

  function showVSMEHistory(supplierId) {
    const supplier = Supplier.getAll().find(s => s.id === supplierId)
    const assessments = Supplier.getVSMEAssessments(supplierId).reverse()
    const body = el('div', { style: 'max-height:400px;overflow-y:auto' })
    if (!assessments.length) {
      body.append(el('p', { style: 'color:#999;text-align:center' }, '진단 이력이 없습니다.'))
    } else {
      assessments.forEach(a => {
        const grade = Supplier.getGrade(a.score)
        body.append(el('div', { style: 'padding:10px;border-bottom:1px solid #f0f0f0;display:flex;justify-content:space-between;align-items:center' },
          el('div', {},
            el('div', { style: 'font-weight:500' }, `${a.mode === 'basic' ? '기본' : '종합'} 모드`),
            el('div', { style: 'font-size:12px;color:#888' }, new Date(a.assessed_at).toLocaleString('ko-KR'))
          ),
          el('span', { style: `background:${grade.color};color:#fff;padding:3px 12px;border-radius:10px;font-size:12px;font-weight:600` }, `${a.score}점 - ${a.grade}등급`)
        ))
      })
    }
    modal(`${supplier?.name || ''} VSME 이력`, body)
    document.getElementById('modal-save').style.display = 'none'
  }

  // ==================== AI 보고서 ====================
  let _aiAssId = null
  function renderAI() {
    const c = document.getElementById('page-ai')
    if (!c) return
    const assessments = Store.getAssessments() || []
    c.innerHTML = ''
    if (!assessments.length) {
      c.append(
        el('div', { className: 'card', style: 'text-align:center;padding:40px 20px' },
          el('div', { style: 'font-size:36px;margin-bottom:12px' }, '🤖'),
          el('h3', { style: 'margin:0 0 8px' }, 'AI 보고서 초안 작성'),
          el('p', { style: 'margin:0 0 16px;color:#888;font-size:13px' }, 'AI 초안 생성을 위해 먼저 평가를 완료하세요.'),
          el('button', { className: 'btn btn-primary', onClick: () => navigate('assessment') }, '+ 평가 생성하러 가기')
        )
      )
      return
    }
    _aiAssId = _aiAssId || assessments[0].id
    if (!assessments.find(a => a.id === _aiAssId)) _aiAssId = assessments[0].id
    const assessment = Store.getAssessments().find(a => a.id === _aiAssId)
    const groups = Indicator.getGroups(assessment.authority_code)
    const indicators = groups.flatMap(g => Store.getIndicators().filter(i => i.group_id === g.id && i.is_active !== false))
    const drafts = Store.getAIDrafts().filter(d => d.assessment_id === _aiAssId)
    c.append(
      el('div', { className: 'card' },
        el('div', { className: 'card-header' },
          el('h3', {}, 'AI 보고서'),
          el('select', { onChange: e => { _aiAssId = parseInt(e.target.value); renderAI() } },
            ...assessments.map(a => el('option', { value: a.id, selected: a.id === _aiAssId }, a.title))
          )
        ),
        el('div', { style: 'display:grid;grid-template-columns:280px 1fr;gap:12px;padding:12px' },
          el('div', {}, ...indicators.map(ind => {
            const draft = drafts.find(d => d.indicator_id === ind.id)
            const sc = draft?.human_status === 'approved' ? '#27ae60' : draft?.ver_status === 'fail' ? '#e74c3c' : draft ? '#f39c12' : '#999'
            const st = draft ? AI.getDraftStatus(draft) : '미생성'
            return el('div', { style: `padding:8px;background:#fff;border-radius:6px;margin-bottom:4px;box-shadow:0 1px 2px rgba(0,0,0,.08);cursor:pointer;border-left:3px solid ${sc}`,
              onClick: () => showAIDetail(ind.id) },
              el('div', { style: 'font-weight:500;font-size:12px' }, Indicator.getNameAndCode(ind)),
              el('div', { style: `font-size:10px;color:${sc}` }, st)
            )
          })),
          el('div', { id: 'aiDetail', style: 'background:#fff;border-radius:8px;padding:16px;box-shadow:0 1px 3px rgba(0,0,0,.1);min-height:200px' },
            el('p', { style: 'color:#999;text-align:center' }, '왼쪽에서 항목을 선택하세요')
          )
        )
      )
    )
  }

  function showAIDetail(indicatorId) {
    const right = document.getElementById('aiDetail')
    if (!right) return
    const indicator = Store.getIndicators().find(i => i.id === indicatorId)
    const drafts = Store.getAIDrafts().filter(d => d.indicator_id === indicatorId && d.assessment_id === _aiAssId)
    const latest = drafts[drafts.length - 1]
    const evidences = Evidence.getByIndicator(_aiAssId, indicatorId)
    right.innerHTML = ''

    const verResult = latest?.ver_result
    const claims = verResult?.claims || []

    right.append(
      el('h4', { style: 'margin:0 0 4px;font-size:14px' }, Indicator.getNameAndCode(indicator)),
      el('div', { style: 'font-size:11px;color:#666;margin-bottom:8px' }, `${Indicator.getPillarName(indicator.pillar)} | 증빙 ${evidences.length}건`),
      latest?.pillar_coverage ? el('div', { style: 'font-size:11px;color:#888;margin-bottom:4px' },
        `필러 커버리지: `,
        latest.pillar_coverage.policy ? el('span', { style: 'color:#27ae60' }, 'Policy ') : el('span', { style: 'color:#ccc' }, 'Policy '),
        latest.pillar_coverage.action ? el('span', { style: 'color:#27ae60' }, 'Action ') : el('span', { style: 'color:#ccc' }, 'Action '),
        latest.pillar_coverage.result ? el('span', { style: 'color:#27ae60' }, 'Result') : el('span', { style: 'color:#ccc' }, 'Result'),
        latest.missing_pillars?.length ? el('span', { style: 'color:#e74c3c;margin-left:4px' }, `(누락: ${latest.missing_pillars.join(', ')})`) : null
      ) : null,
      latest?.confidence ? el('div', { style: 'font-size:11px;margin-bottom:4px;color:' + ({ HIGH: '#27ae60', MEDIUM: '#f39c12', LOW: '#e74c3c' }[latest.confidence] || '#888') }, `신뢰도: ${latest.confidence}`) : null,
      latest ? el('div', { style: 'background:#f8f9fa;border-radius:6px;padding:12px;margin:8px 0;font-size:12px;line-height:1.6;white-space:pre-wrap;max-height:300px;overflow-y:auto' }, latest.draft_text) : null,
      latest ? el('div', { style: 'font-size:11px;margin-bottom:8px' },
        el('span', { style: `color:${latest.ver_status === 'pass' ? '#27ae60' : latest.ver_status === 'fail' ? '#e74c3c' : '#f39c12'}` }, `AI 검증: ${latest.ver_status === 'pass' ? '✅ PASS' : latest.ver_status === 'fail' ? '❌ FAIL' : latest.ver_status === 'revision_needed' ? '⚠️ 수정필요' : '⏳ 대기'}`),
        el('span', { style: 'margin-left:8px' }, `사람: ${latest.human_status === 'approved' ? '✅ 승인' : latest.human_status === 'rejected' ? '❌ 반려' : '⏳ 검토대기'}`)
      ) : null,
      claims.length ? el('div', { style: 'margin:8px 0;border:1px solid #eee;border-radius:6px;overflow:hidden' },
        el('div', { style: 'padding:8px 12px;background:#f8f9fa;font-size:12px;font-weight:600;border-bottom:1px solid #eee' }, `검증 결과 (${claims.length}개 주장)`),
        ...claims.map(c => {
          const colors = { SUPPORTED: '#27ae60', PARTIALLY_SUPPORTED: '#f39c12', UNSUPPORTED: '#e74c3c', MISMATCH: '#e74c3c' }
          const icons = { SUPPORTED: '✅', PARTIALLY_SUPPORTED: '⚠️', UNSUPPORTED: '❌', MISMATCH: '🔴' }
          return el('div', { style: 'padding:8px 12px;border-bottom:1px solid #f0f0f0;font-size:11px' },
            el('div', { style: 'display:flex;align-items:flex-start;gap:6px' },
              el('span', {}, icons[c.status] || '❓'),
              el('div', { style: 'flex:1' },
                el('div', { style: 'color:#333;line-height:1.4' }, c.claim_text),
                el('div', { style: `color:${colors[c.status] || '#888'};margin-top:2px;font-weight:500` }, `${c.status}${c.matched_evidence_id ? ' → ' + c.matched_evidence_id : ''}`),
                c.reason ? el('div', { style: 'color:#888;margin-top:2px' }, c.reason) : null
              )
            )
          )
        }),
        verResult?.revision_notes ? el('div', { style: 'padding:8px 12px;font-size:11px;color:#666;background:#fff9e6' }, el('strong', {}, '수정 노트: '), verResult.revision_notes) : null
      ) : null,
      el('div', { style: 'display:flex;gap:4px;flex-wrap:wrap' },
        el('button', { className: 'btn btn-sm btn-primary', onClick: async () => {
          const btn = event.target; btn.disabled = true; btn.textContent = '생성 중...'
          const r = await AI.generateReport(_aiAssId, indicatorId, currentUser?.role)
          btn.disabled = false; btn.textContent = 'AI 초안 생성'
          showAIDetail(indicatorId)
          if (r.error) alert(r.error)
        }}, 'AI 초안 생성'),
        latest && latest.ver_status === 'pass' && latest.human_status === 'pending' && latest.cited_evidence_ids?.length > 0 ? el('button', { className: 'btn btn-sm btn-success', onClick: () => { Store.updateAIDraft(latest.id, { human_status: 'approved', human_reviewed_at: new Date().toISOString() }); showAIDetail(indicatorId) }}, '✅ 승인') : null,
        latest && latest.ver_status === 'pass' && latest.human_status === 'pending' && (!latest.cited_evidence_ids || latest.cited_evidence_ids.length === 0) ? el('span', { style: 'color:#e74c3c;font-size:11px;font-weight:600;padding:5px 8px;background:#fff5f5;border-radius:6px' }, '⚠ 증빙 미연결 - 승인 불가') : null,
        latest && latest.ver_status === 'pass' && latest.human_status === 'pending' && (() => { const ind = Store.getIndicators().find(i => i.id === indicatorId); return ind && ind.scope2_split_required && Object.keys(GHG.getSummary(_aiAssId)).length === 0 })() ? el('span', { style: 'color:#cf1322;font-size:11px;font-weight:600;padding:5px 8px;background:#fff2f0;border-radius:6px' }, '⚠ GHG 미등록 - Scope2 분할 필요 지표 승인 불가') : null,
        latest && latest.human_status === 'pending' ? el('button', { className: 'btn btn-sm btn-danger', onClick: () => { Store.updateAIDraft(latest.id, { human_status: 'rejected' }); showAIDetail(indicatorId) }}, '반려') : null,
        latest && latest.human_status === 'pending' ? el('button', { className: 'btn btn-sm', onClick: () => { const fb = prompt('수정 요청 사항:'); if (fb) { Store.updateAIDraft(latest.id, { human_status: 'revision_requested', human_feedback: fb }); showAIDetail(indicatorId) } }}, '수정 요청') : null
      ),
      evidences.length ? el('div', { style: 'margin-top:8px;font-size:11px;color:#666' }, el('strong', {}, '증빙: '), ...evidences.map(e => el('span', { style: 'margin-right:4px' }, `[${e.title}]`))) : null
    )
  }

  // ==================== GRI 준수율 ====================
  function renderGRI() {
    const c = document.getElementById('page-gri')
    if (!c) return
    const assessments = Store.getAssessments() || []
    c.innerHTML = ''
    if (!assessments.length) {
      c.append(el('div', { className: 'card', style: 'text-align:center;padding:40px 20px' }, el('div', { style: 'font-size:36px;margin-bottom:12px' }, '📊'), el('h3', { style: 'margin:0 0 8px' }, 'GRI Standards 준수율'), el('p', { style: 'margin:0 0 16px;color:#888;font-size:13px' }, 'GRI 분석을 위해 먼저 평가를 생성하세요.'), el('button', { className: 'btn btn-primary', onClick: () => navigate('assessment') }, '+ 평가 생성하러 가기')))
      return
    }
    if (!_griAssId || !assessments.find(a => a.id === _griAssId)) _griAssId = assessments[0]?.id
    const selectedId = _griAssId
    const report = GRI.generateComplianceReport(selectedId)
    c.append(
      el('div', { className: 'card' },
        el('div', { className: 'card-header' },
          el('h3', {}, 'GRI Standards 준수율'),
          el('div', { style: 'display:flex;gap:8px;align-items:center' },
            el('select', { id: 'griAssSelect', onChange: (e) => { _griAssId = e.target.value; renderGRI() } },
              ...assessments.map(a => el('option', { value: a.id, selected: a.id === selectedId }, a.title))
            )
          )
        ),
        el('div', { style: 'padding:12px 20px;background:#f8f9fa;border-bottom:1px solid #eee;font-size:13px;display:flex;gap:24px' },
          el('span', {}, `완전준수: <strong style="color:#27ae60">${report.rate.full_rate}%</strong>`),
          el('span', {}, `부분준수 포함: <strong style="color:#f39c12">${report.rate.with_ref_rate}%</strong>`),
          el('span', {}, `필수 항목: <strong>${report.rate.total_required}개</strong>`),
          el('span', {}, `완전: <strong>${report.rate.full_compliance}</strong>`),
          el('span', {}, `부분: <strong>${report.rate.with_reference}</strong>`),
          el('span', {}, `미준수: <strong style="color:#e74c3c">${report.rate.non_compliant}</strong>`)
        ),
        el('div', { innerHTML: report.html, style: 'padding:16px 20px' })
      )
    )
  }

  // ==================== 리스크 예측 ====================
  function renderRisk() {
    const c = document.getElementById('page-risk')
    if (!c) return
    const assessments = Store.getAssessments() || []
    c.innerHTML = ''
    if (!assessments.length) {
      c.append(el('div', { className: 'card', style: 'text-align:center;padding:40px 20px' }, el('div', { style: 'font-size:36px;margin-bottom:12px' }, '⚠️'), el('h3', { style: 'margin:0 0 8px' }, 'AI 리스크 예측'), el('p', { style: 'margin:0 0 16px;color:#888;font-size:13px' }, '리스크 분석을 위해 먼저 평가를 생성하세요.'), el('button', { className: 'btn btn-primary', onClick: () => navigate('assessment') }, '+ 평가 생성하러 가기')))
      return
    }
    if (!_riskAssId || !assessments.find(a => a.id === _riskAssId)) _riskAssId = assessments[0]?.id
    const selectedId = _riskAssId
    const report = RISK.generateReport(selectedId)
    c.append(
      el('div', { className: 'card' },
        el('div', { className: 'card-header' },
          el('h3', {}, 'AI 리스크 예측'),
          el('select', { id: 'riskAssSelect', onChange: (e) => { _riskAssId = e.target.value; renderRisk() } },
            ...assessments.map(a => el('option', { value: a.id, selected: a.id === selectedId }, a.title))
          )
        ),
        el('div', { innerHTML: report.html, style: 'padding:16px 20px' })
      )
    )
  }

  // ==================== 벤치마크 모니터링 ====================
  function renderMonitor() {
    const c = document.getElementById('page-monitor')
    if (!c) return
    const assessments = Store.getAssessments() || []
    c.innerHTML = ''
    if (!assessments.length) {
      c.append(el('div', { className: 'card', style: 'text-align:center;padding:40px 20px' }, el('div', { style: 'font-size:36px;margin-bottom:12px' }, '📈'), el('h3', { style: 'margin:0 0 8px' }, '벤치마크 모니터링'), el('p', { style: 'margin:0 0 16px;color:#888;font-size:13px' }, '벤치마크 비교를 위해 먼저 평가를 생성하세요.'), el('button', { className: 'btn btn-primary', onClick: () => navigate('assessment') }, '+ 평가 생성하러 가기')))
      return
    }
    if (!_monitorAssId || !assessments.find(a => a.id === _monitorAssId)) _monitorAssId = assessments[0]?.id
    const selectedId = _monitorAssId
    const benchmarks = MONITORING.getBenchmarks()
    const industries = el('div', { style: 'display:grid;grid-template-columns:repeat(auto-fit,minmax(140px,1fr));gap:10px;margin-bottom:16px' },
      ...benchmarks.industries.map(ind => el('div', { style: 'background:#fff;border-radius:8px;padding:12px;box-shadow:0 1px 3px rgba(0,0,0,.1);text-align:center' },
        el('div', { style: 'font-size:11px;color:#888' }, ind.label),
        el('div', { style: 'font-size:20px;font-weight:700;color:#7C3AED' }, ind.avg_score),
        el('div', { style: 'font-size:10px;color:#aaa' }, `${ind.sample_size}개사`)
      ))
    )
    const industrySelect = el('select', { id: 'monitorIndustry', onChange: (e) => { _monitorIndustry = e.target.value } },
      benchmarks.industries.map(ind => el('option', { value: ind.code, selected: ind.code === _monitorIndustry }, `${ind.label} (${ind.avg_score}점)`))
    )
    const compareBtn = el('button', { className: 'btn btn-primary', onClick: () => {
      const report = MONITORING.generateReport(selectedId, _monitorIndustry)
      document.getElementById('monitorResult').innerHTML = report
    }}, '벤치마크 비교 실행')
    c.append(
      el('div', { className: 'card' },
        el('div', { className: 'card-header' }, el('h3', {}, '📈 실시간 벤치마크 모니터링')),
        el('div', { style: 'padding:16px 20px' },
          el('p', { style: 'font-size:12px;color:#888;margin-bottom:12px' }, `글로벌 평균: ${benchmarks.global_avg}점 | 출처: ${benchmarks.sample_source} | 갱신: ${benchmarks.last_updated}`),
          industries,
          el('div', { style: 'display:flex;gap:8px;align-items:center;margin-bottom:12px' },
            el('span', { style: 'font-size:12px;color:#666' }, '비교 대상 업종:'),
            industrySelect,
            el('span', { style: 'font-size:12px;color:#666' }, '내 평가:'),
            el('select', { id: 'monitorAss', onChange: (e) => { _monitorAssId = e.target.value } },
              assessments.map(a => el('option', { value: a.id, selected: a.id === selectedId }, `${a.title} (${a.assessment_year}년)`))
            ),
            compareBtn
          ),
          el('div', { id: 'monitorResult' })
        )
      )
    )
  }

  // ==================== ISSA 5000 감사 보증 ====================
  function renderISSA() {
    const c = document.getElementById('page-issa')
    if (!c) return
    const companyId = (Store.getCompanies()[0]?.id) || 'default'
    const companyName = (Store.getCompanies()[0]?.name) || '회사명'
    const assurance = ISSA.getAssurance(companyId)
    const completion = ISSA.getCompletionPercent(assurance)
    const stageInfo = ISSA.getStageInfo(assurance.stage)
    const stages = ISSA_STAGES.map(s => {
      const isActive = s.key === assurance.stage
      const isPast = ISSA_STAGES.findIndex(x => x.key === s.key) < ISSA_STAGES.findIndex(x => x.key === assurance.stage)
      return el('div', { style: `flex:1;text-align:center;padding:10px;${isActive ? 'background:#f8f6ff;border-radius:8px;border:2px solid #7C3AED' : isPast ? 'opacity:.6' : ''}` },
        el('div', { style: 'font-size:20px' }, s.icon),
        el('div', { style: `font-size:11px;font-weight:${isActive ? '700' : '400'};color:${isActive ? '#7C3AED' : '#666'}` }, s.label)
      )
    })
    const findingForm = el('div', { style: 'margin-top:12px' },
      el('div', { className: 'form-group' }, el('label', {}, '지적사항 유형'), el('select', { id: 'findCategory' },
        ['환경', '사회', '지배구조', '데이터', '절차', '기타'].map(cat => el('option', { value: cat }, cat))
      )),
      el('div', { className: 'form-group' }, el('label', {}, '심각도'), el('select', { id: 'findSeverity' },
        [{ key: 'low', label: '낮음' }, { key: 'medium', label: '보통' }, { key: 'high', label: '높음' }].map(s => el('option', { value: s.key }, s.label))
      )),
      el('div', { className: 'form-group' }, el('label', {}, '설명'), el('textarea', { id: 'findDesc', rows: 2, style: 'width:100%;padding:8px;border:1px solid #ddd;border-radius:6px' })),
      el('div', { className: 'form-group' }, el('label', {}, '권고사항'), el('textarea', { id: 'findRec', rows: 2, style: 'width:100%;padding:8px;border:1px solid #ddd;border-radius:6px' }))
    )
    const statement = ISSA.generateStatement(assurance, companyName)
    c.append(
      el('div', { className: 'card' },
        el('div', { className: 'card-header' },
          el('h3', {}, '🛡️ ISSA 5000 감사 보증'),
          el('div', { style: 'font-size:12px;color:#888' }, `완료율: ${completion}%`)
        ),
        el('div', { style: 'padding:16px 20px;display:flex;gap:8px;align-items:center;border-bottom:1px solid #eee' }, ...stages),
        el('div', { style: 'padding:16px 20px;display:flex;gap:24px;font-size:13px;border-bottom:1px solid #eee;flex-wrap:wrap' },
          el('span', {}, `감사인: <strong>${assurance.auditor_name || '-'}</strong>`),
          el('span', {}, `감사기관: <strong>${assurance.auditor_firm || '-'}</strong>`),
          el('span', {}, `보증수준: <strong>${ISSA.getAssuranceLevel(assurance.assurance_level)?.label || assurance.assurance_level}</strong>`),
          el('span', {}, `미해결: <strong style="color:#e74c3c">${assurance.findings?.filter(f => f.status === 'open').length || 0}건</strong>`)
        )
      ),
      el('div', { className: 'card' },
        el('div', { className: 'card-header' },
          el('h3', {}, '감사 기본 정보'),
          el('div', { style: 'display:flex;gap:6px' },
            ISSA_STAGES.map(s => el('button', { className: 'btn btn-sm' + (s.key === assurance.stage ? ' btn-primary' : ''), onClick: () => { ISSA.setStage(companyId, s.key); renderISSA() } }, `${s.icon} ${s.label}`))
          )
        ),
        el('div', { style: 'padding:16px 20px;display:grid;grid-template-columns:1fr 1fr;gap:12px' },
          el('div', { className: 'form-group' }, el('label', {}, '감사인명'), el('input', { id: 'issaAuditor', value: assurance.auditor_name || '', onBlur: e => { assurance.auditor_name = e.target.value; ISSA.saveAssurance(assurance) } })),
          el('div', { className: 'form-group' }, el('label', {}, '감사기관'), el('input', { id: 'issaFirm', value: assurance.auditor_firm || '', onBlur: e => { assurance.auditor_firm = e.target.value; ISSA.saveAssurance(assurance) } })),
          el('div', { className: 'form-group' }, el('label', {}, '면허번호'), el('input', { id: 'issaLicense', value: assurance.auditor_license || '', onBlur: e => { assurance.auditor_license = e.target.value; ISSA.saveAssurance(assurance) } })),
          el('div', { className: 'form-group' }, el('label', {}, '보증 수준'), el('select', { id: 'issaLevel', onChange: e => { assurance.assurance_level = e.target.value; ISSA.saveAssurance(assurance); renderISSA() } },
            ASSURANCE_LEVELS.map(l => el('option', { value: l.key, selected: l.key === assurance.assurance_level }, `${l.label} (${l.description})`))
          )),
          el('div', { className: 'form-group' }, el('label', {}, '감사 시작일'), el('input', { type: 'date', id: 'issaStart', value: assurance.scope_start || '', onBlur: e => { assurance.scope_start = e.target.value; ISSA.saveAssurance(assurance) } })),
          el('div', { className: 'form-group' }, el('label', {}, '감사 종료일'), el('input', { type: 'date', id: 'issaEnd', value: assurance.scope_end || '', onBlur: e => { assurance.scope_end = e.target.value; ISSA.saveAssurance(assurance) } })),
          el('div', { className: 'form-group' }, el('label', {}, '중대성 기준(%)'), el('input', { type: 'number', id: 'issaThresh', value: assurance.materiality_threshold || 10, onBlur: e => { assurance.materiality_threshold = parseInt(e.target.value) || 10; ISSA.saveAssurance(assurance) } })),
          el('div', { className: 'form-group' }, el('label', {}, '서명일'), el('input', { type: 'date', id: 'issaSign', value: assurance.sign_date || '', onBlur: e => { assurance.sign_date = e.target.value; ISSA.saveAssurance(assurance) } }))
        )
      ),
      el('div', { className: 'card' },
        el('div', { className: 'card-header' },
          el('h3', {}, `지적사항 (${assurance.findings?.length || 0}건)`),
          el('button', { className: 'btn btn-primary btn-sm', onClick: () => {
            const desc = document.getElementById('findDesc')?.value
            if (!desc) return alert('설명을 입력하세요')
            ISSA.addFinding(companyId, {
              category: document.getElementById('findCategory')?.value,
              severity: document.getElementById('findSeverity')?.value,
              description: desc,
              recommendation: document.getElementById('findRec')?.value
            })
            renderISSA()
          }}, '+ 지적사항 추가')
        ),
        findingForm,
        assurance.findings?.length ? el('table', { style: 'font-size:12px' },
          el('thead', {}, el('tr', {}, el('th', {}, 'ID'), el('th', {}, '유형'), el('th', {}, '심각도'), el('th', {}, '설명'), el('th', {}, '상태'), el('th', {}, '관리'))),
          el('tbody', {}, ...assurance.findings.map(f => {
            const sevColors = { high: '#e74c3c', medium: '#f39c12', low: '#3498db' }
            const sevLabels = { high: '높음', medium: '보통', low: '낮음' }
            return el('tr', {},
              el('td', {}, f.id),
              el('td', {}, f.category),
              el('td', { style: `color:${sevColors[f.severity]};font-weight:600` }, sevLabels[f.severity] || f.severity),
              el('td', {}, f.description),
              el('td', { style: f.status === 'open' ? 'color:#e74c3c;font-weight:600' : 'color:#27ae60' }, f.status === 'open' ? '미해결' : '해결완료'),
              el('td', {}, f.status === 'open' ? el('button', { className: 'btn btn-sm btn-success', onClick: () => { ISSA.resolveFinding(companyId, f.id); renderISSA() } }, '해결처리') : null)
            )
          }))
        ) : el('p', { style: 'padding:16px;color:#999;text-align:center' }, '지적사항이 없습니다.')
      ),
      el('div', { className: 'card' },
        el('div', { className: 'card-header' }, el('h3', {}, '보증 의견서')),
        el('div', { innerHTML: ISSA.generateReport(companyId), style: 'padding:16px 20px' })
      )
    )
  }

  // ==================== 평가기관 제출 ====================
  function renderSubmit() {
    const c = document.getElementById('page-submit')
    if (!c) return
    const companyId = (Store.getCompanies()[0]?.id) || 'default'
    const submissions = SUBMISSION.getSubmissions(companyId)
    const agencies = SUBMISSION.getAgencies()
    c.innerHTML = ''
    c.append(
      el('div', { className: 'card' },
        el('div', { className: 'card-header' },
          el('h3', {}, '📤 평가기관 자동 제출'),
          el('button', { className: 'btn btn-primary', onClick: () => {
            modal('평가기관 추가', el('div', {},
              el('div', { className: 'form-group' }, el('label', {}, '평가기관'), el('select', { id: 'subAgency' },
                agencies.map(a => el('option', { value: a.code }, `${a.name} (${a.country})`))
              )),
              el('div', { className: 'form-group' }, el('label', {}, '대상 연도'), el('input', { type: 'number', id: 'subYear', value: new Date().getFullYear() - 1 }))
            ))
            document.getElementById('modal-save').onclick = () => {
              SUBMISSION.addSubmission(companyId, document.getElementById('subAgency').value, parseInt(document.getElementById('subYear').value))
              closeModal(); renderSubmit()
            }
          }}, '+ 평가기관 추가')
        ),
        submissions.length ? el('div', { innerHTML: SUBMISSION.generateReport(companyId) }) : el('p', { style: 'padding:20px;color:#999' }, '등록된 제출이 없습니다. 평가기관을 추가해주세요.')
      ),
      el('div', { className: 'card' },
        el('div', { className: 'card-header' }, el('h3', {}, '평가기관별 제출 현황')),
        el('table', { style: 'font-size:12px' },
          el('thead', {}, el('tr', {}, el('th', {}, '기관'), el('th', {}, '포맷'), el('th', {}, '상태'), el('th', {}, '설명'))),
          el('tbody', {}, ...agencies.map(a => {
            const sub = submissions.find(s => s.agency_code === a.code)
            const statusColors = { available: '#27ae60', pending: '#f39c12', not_available: '#ccc' }
            return el('tr', {},
              el('td', { style: 'font-weight:600' }, a.name),
              el('td', {}, a.format),
              el('td', { style: `color:${statusColors[a.status]};font-weight:600` }, { available: '사용가능', pending: '준비중', not_available: '미지원' }[a.status]),
              el('td', { style: 'font-size:11px;color:#888' }, a.description),
              el('td', {}, sub ? el('span', { style: 'color:#27ae60;font-size:11px' }, `✓ 등록됨 (준비율 ${SUBMISSION.calcReadiness(sub)}%)`) : null)
            )
          }))
        )
      )
    )
  }

  // ==================== ERP/API 연동 ====================
  function renderAPI() {
    const c = document.getElementById('page-api')
    if (!c) return
    const endpoints = API.getEndpoints() || []
    const status = API.getSyncStatus()
    c.innerHTML = ''
    c.append(
      el('div', { className: 'card' },
        el('div', { className: 'card-header' }, el('h3', {}, '🔌 ERP/API 데이터 연동')),
        el('div', { style: 'padding:12px 20px;background:#f8f9fa;border-bottom:1px solid #eee;font-size:13px;display:flex;gap:24px' },
          el('span', {}, `활성 엔드포인트: <strong>${status.active_endpoints}/${status.total_endpoints}</strong>`),
          el('span', {}, `총 레코드: <strong>${status.total_records}</strong>`),
          el('span', {}, `마지막 동기화: <strong>${status.latest_sync}</strong>`)
        )
      ),
      el('div', { className: 'card' },
        el('div', { className: 'card-header' }, el('h3', {}, '엔드포인트 목록')),
        el('table', { style: 'font-size:12px' },
          el('thead', {}, el('tr', {}, el('th', {}, 'ID'), el('th', {}, '이름'), el('th', {}, '소스'), el('th', {}, '카테고리'), el('th', {}, '방식'), el('th', {}, '상태'), el('th', {}, '마지막동기화'), el('th', {}, '레코드수'), el('th', {}, '관리'))),
          el('tbody', {}, ...endpoints.map(ep => el('tr', {},
            el('td', { style: 'font-family:monospace;font-size:11px' }, ep.id),
            el('td', {}, ep.name),
            el('td', {}, ep.source),
            el('td', {}, ep.category),
            el('td', {}, ep.method),
            el('td', { style: ep.status === 'active' ? 'color:#27ae60;font-weight:600' : 'color:#999' }, ep.status === 'active' ? '활성' : '비활성'),
            el('td', {}, ep.last_sync ? new Date(ep.last_sync).toLocaleString('ko-KR') : '-'),
            el('td', { style: 'text-align:center' }, ep.record_count),
            el('td', {}, el('button', { className: 'btn btn-sm' + (ep.status === 'active' ? ' btn-danger' : ' btn-success'), onClick: () => { API.toggleEndpoint(ep.id); renderAPI() } }, ep.status === 'active' ? '비활성화' : '활성화'))
          )))
        )
      ),
      el('div', { className: 'card' },
        el('div', { className: 'card-header' },
          el('h3', {}, '📥 CSV 데이터 가져오기')
        ),
        el('div', { style: 'padding:16px 20px' },
          el('div', { className: 'form-group' }, el('label', {}, '데이터 카테고리'), el('select', { id: 'csvCategory' },
            ['ghg', 'energy', 'water', 'waste', 'workforce', 'safety', 'training', 'supply_chain', 'financial'].map(cat => el('option', { value: cat }, cat))
          )),
          el('div', { className: 'form-group' }, el('label', {}, 'CSV 입력'), el('textarea', { id: 'csvInput', rows: 6, placeholder: '헤더 포함 CSV를 붙여넣으세요...\n\n예시: year,scope,category,quantity,unit\n2024,scope1,diesel,1000,liter', style: 'width:100%;padding:8px;border:1px solid #ddd;border-radius:6px;font-family:monospace;font-size:11px' })),
          el('div', { style: 'display:flex;gap:8px;align-items:center' },
            el('button', { className: 'btn btn-secondary', onClick: () => {
              const cat = document.getElementById('csvCategory').value
              const template = API.getImportTemplate(cat)
              document.getElementById('csvInput').value = template
            }}, '템플릿 다운로드'),
            el('button', { className: 'btn btn-primary', onClick: () => {
              const cat = document.getElementById('csvCategory').value
              const raw = document.getElementById('csvInput').value
              if (!raw.trim()) return alert('CSV 데이터를 입력하세요')
              const parsed = API.parseCSV(raw)
              if (parsed.errors.length) { alert('파싱 오류:\n' + parsed.errors.join('\n')); return }
              const result = API.importData(cat, parsed.data)
              alert(`가져오기 완료: ${result.imported}건 성공, ${result.errors.length}건 오류`)
              renderAPI()
            }}, '가져오기 실행'),
            el('button', { className: 'btn btn-secondary', onClick: () => {
              const cat = document.getElementById('csvCategory').value
              const schema = API.getSchema(cat)
              if (!schema) return alert('해당 카테고리의 스키마가 없습니다.')
              const msg = `필수 필드: ${schema.required.join(', ')}\n선택 필드: ${schema.optional.join(', ')}`
              alert(msg)
            }}, '스키마 보기')
          ),
          el('div', { id: 'csvPreview', style: 'margin-top:12px;font-size:11px;color:#888' })
        )
      ),
      el('div', { className: 'card' },
        el('div', { className: 'card-header' }, el('h3', {}, '📡 API 페이로드 예시')),
        el('div', { style: 'padding:16px 20px' },
          el('div', { className: 'form-group' }, el('label', {}, '카테고리 선택'), el('select', { id: 'exampleCat', onChange: () => {
            const cat = document.getElementById('exampleCat').value
            const example = API.generatePayloadExample(cat)
            document.getElementById('examplePayload').textContent = JSON.stringify(example, null, 2)
          }},
            ['ghg', 'energy', 'water', 'waste', 'workforce', 'safety', 'training', 'supply_chain', 'financial'].map(cat => el('option', { value: cat }, cat))
          )),
          el('pre', { id: 'examplePayload', style: 'background:#f8f9fa;padding:12px;border-radius:6px;font-size:11px;overflow-x:auto;max-height:200px' }, JSON.stringify(API.generatePayloadExample('ghg'), null, 2))
        )
      )
    )
  }

  // ==================== 보고서 편집기 (S-05) ====================
  let _editorAssId = null
  let _editorSelectedIndicator = null

  function renderReportEditor() {
    const c = document.getElementById('page-editor')
    if (!c) return
    const assessments = Store.getAssessments() || []
    c.innerHTML = ''
    if (!assessments.length) {
      c.append(
        el('div', { className: 'card', style: 'text-align:center;padding:40px 20px' },
          el('div', { style: 'font-size:36px;margin-bottom:12px' }, '📝'),
          el('h3', { style: 'margin:0 0 8px' }, '보고서 편집기'),
          el('p', { style: 'margin:0 0 16px;color:#888;font-size:13px' }, '지표 ↔ 증빙 연결을 위해 먼저 평가를 생성하세요.'),
          el('button', { className: 'btn btn-primary', onClick: () => navigate('assessment') }, '+ 평가 생성하러 가기')
        )
      )
      return
    }
    _editorAssId = _editorAssId || assessments[0].id
    if (!assessments.find(a => a.id === _editorAssId)) _editorAssId = assessments[0].id
    const assessment = Store.getAssessments().find(a => a.id === _editorAssId)
    const allIndicators = Store.getIndicators().filter(i => i.authority_code === assessment.authority_code && i.is_active !== false)
    const evidences = Evidence.getAll(_editorAssId)

    c.append(
      el('div', { className: 'card' },
        el('div', { className: 'card-header' },
          el('h3', {}, '📝 보고서 편집기 — 지표 ↔ 증빙 연결'),
          el('div', { style: 'display:flex;gap:8px;align-items:center' },
            el('select', { id: 'editorAssSelect', onChange: () => { _editorAssId = parseInt(document.getElementById('editorAssSelect').value); _editorSelectedIndicator = null; renderReportEditor() } },
              ...assessments.map(a => el('option', { value: a.id, selected: a.id === _editorAssId }, `${a.title} (${a.assessment_year}년)`))
            )
          )
        ),
        el('div', { style: 'display:grid;grid-template-columns:320px 1fr;gap:0;min-height:500px' },
          el('div', { style: 'border-right:1px solid #eee;overflow-y:auto;max-height:600px' },
            el('div', { style: 'padding:10px 16px;background:#f8f9fa;border-bottom:1px solid #eee;font-size:12px;font-weight:600;color:#555' }, `지표 목록 (${allIndicators.length}개)`),
            ...allIndicators.map(ind => {
              const tags = Store.getEvidenceTags().filter(t => t.indicator_id === ind.id)
              const isSelected = _editorSelectedIndicator === ind.id
              return el('div', {
                style: `padding:10px 16px;border-bottom:1px solid #f0f0f0;cursor:pointer;${isSelected ? 'background:#f0ebff;border-left:3px solid #7C3AED' : ''}`,
                onClick: () => { _editorSelectedIndicator = ind.id; renderReportEditor() }
              },
                el('div', { style: 'display:flex;justify-content:space-between;align-items:center' },
                  el('span', { style: 'font-weight:500;font-size:13px' }, Indicator.getNameAndCode(ind)),
                  tags.length ? el('span', { style: 'background:#7C3AED;color:#fff;font-size:10px;padding:1px 6px;border-radius:99px' }, tags.length) : null
                ),
                el('div', { style: 'font-size:11px;color:#888;margin-top:2px' }, `${Indicator.getPillarName(ind.pillar)} | ${ind.dept_code || '미지정'}`)
              )
            })
          ),
          el('div', { style: 'overflow-y:auto;max-height:600px;padding:16px' },
            _editorSelectedIndicator ? renderEditorDetail(_editorSelectedIndicator, evidences) : el('div', { style: 'text-align:center;padding:60px 20px;color:#999' },
              el('div', { style: 'font-size:32px;margin-bottom:8px' }, '👈'),
              el('div', { style: 'font-size:13px' }, '왼쪽에서 지표를 선택하면 연결할 증빙을 관리할 수 있습니다.')
            )
          )
        )
      )
    )
  }

  function renderEditorDetail(indicatorId, evidences) {
    const indicator = Store.getIndicators().find(i => i.id === indicatorId)
    if (!indicator) return el('div', {}, '지표를 찾을 수 없습니다.')
    const linkedTags = Store.getEvidenceTags().filter(t => t.indicator_id === indicatorId)
    const linkedEvidences = linkedTags.map(t => evidences.find(e => e.id === t.evidence_id)).filter(Boolean)
    const unlinkedEvidences = evidences.filter(e => !linkedTags.find(t => t.evidence_id === e.id))

    const container = el('div', {})

    const ghgWarning = indicator.scope2_split_required ? (() => {
      const summary = GHG.getSummary(_editorAssId)
      const hasData = Object.keys(summary).length > 0
      if (hasData) {
        return el('div', { style: 'margin-bottom:16px;padding:12px;background:#fffbe6;border:1px solid #ffe58f;border-radius:8px;border-left:3px solid #faad14' },
          el('div', { style: 'font-weight:600;font-size:13px;color:#d48806' }, '📊 Scope2 분할 필요 지표 — GHG 요약 자동 인용'),
          el('div', { style: 'font-size:12px;color:#888;margin-top:4px' }, '이 지표는 Scope 2의 위치기준·시장기준 분할이 필요합니다.'),
          el('pre', { style: 'margin:8px 0 0;padding:8px;background:#fff;border-radius:4px;font-size:12px;white-space:pre-wrap' }, GHG.formatSummary(summary))
        )
      } else {
        return el('div', { style: 'margin-bottom:16px;padding:12px;background:#fff2f0;border:1px solid #ffccc7;border-radius:8px;border-left:3px solid #ff4d4f' },
          el('div', { style: 'font-weight:600;font-size:13px;color:#cf1322' }, '⚠️ Scope2 분할 필요 지표 — GHG 데이터 없음'),
          el('div', { style: 'font-size:12px;color:#888;margin-top:4px' }, '이 지표는 Scope 2 위치기준·시장기준 분할이 필요하지만, GHG 활동자료가 없습니다.'),
          el('div', { style: 'font-size:12px;color:#cf1322;margin-top:4px;font-weight:500' }, '온실가스 관리(S-04)에서 활동자료를 먼저 등록해주세요. 미등록 시 승인이 차단됩니다.')
        )
      }
    })() : null

    container.append(
      el('div', { style: 'margin-bottom:16px;padding:12px;background:#f8f6ff;border-radius:8px;border-left:3px solid #7C3AED' },
        el('div', { style: 'font-weight:600;font-size:14px' }, Indicator.getNameAndCode(indicator)),
        el('div', { style: 'font-size:12px;color:#666;margin-top:4px' }, `${Indicator.getPillarName(indicator.pillar)} | 담당: ${indicator.dept_code || '미지정'} | 주기: ${indicator.review_cycle || '-'}`),
        el('div', { style: 'font-size:12px;color:#888;margin-top:4px' }, `연결된 증빙: ${linkedEvidences.length}건`)
      ),
      ghgWarning,
      el('div', { style: 'margin-bottom:16px' },
        el('h4', { style: 'font-size:13px;margin-bottom:8px;color:#27ae60' }, `✅ 연결된 증빙 (${linkedEvidences.length}건)` ),
        linkedEvidences.length ? el('div', {}, ...linkedEvidences.map(ev =>
          el('div', { style: 'display:flex;align-items:center;justify-content:space-between;padding:8px 12px;background:#f0fff4;border:1px solid #c6f6d5;border-radius:6px;margin-bottom:6px' },
            el('div', {},
              el('div', { style: 'font-weight:500;font-size:13px' }, ev.title),
              el('div', { style: 'font-size:11px;color:#888' }, `${ev.file_type} | ${Evidence.getStatusLabel(ev.status)}${ev.contains_sensitive_data ? ' | 🔒 민감정보' : ''}`)
            ),
            el('button', { className: 'btn btn-sm btn-danger', onClick: () => {
              Store.removeEvidenceTag(ev.id, indicatorId)
              renderReportEditor()
            }}, '해제')
          )
        )) : el('div', { style: 'padding:12px;color:#999;font-size:12px;text-align:center;background:#f9f9f9;border-radius:6px' }, '연결된 증빙이 없습니다. 아래에서 연결하세요.')
      ),
      el('div', { style: 'margin-bottom:16px' },
        el('h4', { style: 'font-size:13px;margin-bottom:8px;color:#666' }, `📎 연결 가능한 증빙 (${unlinkedEvidences.length}건)`),
        unlinkedEvidences.length ? el('div', {}, ...unlinkedEvidences.map(ev =>
          el('div', { style: 'display:flex;align-items:center;justify-content:space-between;padding:8px 12px;background:#fff;border:1px solid #eee;border-radius:6px;margin-bottom:6px' },
            el('div', {},
              el('div', { style: 'font-weight:500;font-size:13px' }, ev.title),
              el('div', { style: 'font-size:11px;color:#888' }, `${ev.file_type} | ${Evidence.getStatusLabel(ev.status)}${ev.contains_sensitive_data ? ' | 🔒 민감정보' : ''}`)
            ),
            el('button', { className: 'btn btn-sm btn-primary', onClick: () => {
              Store.addEvidenceTag({ evidence_id: ev.id, indicator_id: indicatorId })
              renderReportEditor()
            }}, '연결')
          )
        )) : el('div', { style: 'padding:12px;color:#999;font-size:12px;text-align:center;background:#f9f9f9;border-radius:6px' }, '연결 가능한 증빙이 없습니다. 먼저 증빙을 등록하세요.')
      ),
      el('div', { style: 'padding:12px;background:#f8f9fa;border-radius:8px;font-size:12px;color:#666;line-height:1.6' },
        el('strong', {}, '📌 연결 규칙:'),
        el('br'),
        '• 증빙을 연결해야 AI가 해당 증빙만 참조하여 초안을 생성합니다.',
        el('br'),
        '• 연결되지 않은 문장은 AI 검증에서 UNSUPPORTED로 표시됩니다.',
        el('br'),
        '• 미연결 문장이 있으면 최종 승인이 차단됩니다.',
        el('br'),
        indicator.scope2_split_required ? '• 이 지표는 Scope2 분할이 필요하므로 GHG 데이터가 반드시 있어야 합니다.' : null
      )
    )
    return container
  }

  // ==================== KSSB 공시관리 (S-12) ====================
  function renderKSSB() {
    const c = document.getElementById('page-kssb')
    if (!c) return
    c.innerHTML = ''
    const kssbGroups = Indicator.getGroups('KSSB')
    const allKssbInd = Store.getIndicators().filter(i => i.authority_code === 'KSSB' && i.is_active !== false)
    const agency = Store.getAgencyMaster().find(a => a.code === 'KSSB')
    c.append(
      el('div', { className: 'card' },
        el('div', { className: 'card-header' },
          el('h3', {}, '📜 KSSB 공시관리 (법정 공시)'),
          el('span', { style: 'background:#e74c3c;color:#fff;font-size:11px;padding:2px 8px;border-radius:99px' }, '법정 의무 (MANDATORY)')
        ),
        el('div', { style: 'padding:12px 20px;background:#fff5f5;border-bottom:1px solid #eee;font-size:12px;line-height:1.6' },
          `<strong>KSSB 공시기준</strong>: ${agency?.disclosure_std_no || '제1호(일반사항), 제2호(기후)'} | 시행일: ${agency?.effective_date || '2026-02-26'}`,
          el('br'),
          '법정 공시 항목입니다. EcoVadis 등 자율 평가와 성격이 다르며, 미공시 시 과태료가 부과될 수 있습니다.'
        )
      ),
      ...kssbGroups.map(g => {
        const inds = allKssbInd.filter(i => i.group_id === g.id)
        if (!inds.length) return null
        return el('div', { className: 'card' },
          el('div', { className: 'card-header' }, el('h3', { style: 'font-size:14px' }, `${Indicator.getGroupDisplayName(g)} (${inds.length}개 항목)`)),
          el('table', { style: 'font-size:12px' },
            el('thead', {}, el('tr', {}, el('th', { style: 'width:120px' }, '코드'), el('th', {}, '항목명'), el('th', { style: 'width:100px' }, '담당부서'), el('th', { style: 'width:80px' }, '검토주기'), el('th', { style: 'width:80px;text-align:center' }, '_SCOPE2 이중'))),
            el('tbody', {}, ...inds.map(ind => el('tr', {},
              el('td', { style: 'font-family:monospace;font-size:11px;font-weight:500' }, ind.indicator_code),
              el('td', {}, ind.indicator_name),
              el('td', { style: 'font-size:11px;color:#666' }, ind.dept_code || el('span', { style: 'color:#e74c3c' }, '미지정')),
              el('td', { style: 'font-size:11px' }, ind.review_cycle || '-'),
              el('td', { style: 'text-align:center' }, ind.scope2_split_required ? el('span', { style: 'color:#e74c3c;font-weight:600;font-size:11px' }, '위치+시장') : '-')
            )))
          )
        )
      }).filter(Boolean)
    )
  }

  // ==================== AI 생성이력 검토 (S-13) ====================
  function renderAIHistory() {
    const c = document.getElementById('page-aihistory')
    if (!c) return
    const allDrafts = Store.getAIDrafts() || []
    const sorted = [...allDrafts].sort((a, b) => (b.created_at || '').localeCompare(a.created_at || ''))
    const pendingReview = sorted.filter(d => d.ver_status === 'pass' && d.human_status === 'pending')
    const approved = sorted.filter(d => d.human_status === 'approved')
    const rejected = sorted.filter(d => d.human_status === 'rejected')
    c.innerHTML = ''
    c.append(
      el('div', { className: 'card' },
        el('div', { className: 'card-header' },
          el('h3', {}, '🕐 AI 생성이력 검토'),
          el('div', { style: 'display:flex;gap:12px;font-size:12px' },
            el('span', {}, `검토대기: <strong style="color:#f39c12">${pendingReview.length}</strong>`),
            el('span', {}, `승인됨: <strong style="color:#27ae60">${approved.length}</strong>`),
            el('span', {}, `반려: <strong style="color:#e74c3c">${rejected.length}</strong>`)
          )
        )
      ),
      el('div', { className: 'card' },
        el('div', { className: 'card-header' }, el('h3', {}, `검토 대기 (${pendingReview.length}건)`)),
        pendingReview.length ? el('table', { style: 'font-size:12px' },
          el('thead', {}, el('tr', {}, el('th', {}, '지표'), el('th', { style: 'width:50px' }, '버전'), el('th', {}, '증빙'), el('th', {}, '신뢰도'), el('th', { style: 'width:70px' }, '검증'), el('th', { style: 'width:60px' }, '마스킹'), el('th', { style: 'width:100px' }, '관리'))),
          el('tbody', {}, ...pendingReview.map(d => {
            const ind = Store.getIndicators().find(i => i.id === d.indicator_id)
            const assessment = Store.getAssessments().find(a => a.id === d.assessment_id)
            const unsupported = d.ver_result?.claims?.filter(c => c.status === 'UNSUPPORTED' || c.status === 'MISMATCH') || []
            const evidenceCount = d.cited_evidence_ids?.length || d.evidence_ids?.length || 0
            const hasEvidence = evidenceCount > 0
            return el('tr', { style: hasEvidence ? '' : 'background:#fff8f0' },
              el('td', {}, ind ? Indicator.getNameAndCode(ind) : d.indicator_id),
              el('td', { style: 'text-align:center' }, `v${d.version || 1}`),
              el('td', { style: 'font-size:11px' }, hasEvidence ? `${evidenceCount}건 연결` : el('span', { style: 'color:#e74c3c;font-weight:600' }, '⚠ 증빙 미연결')),
              el('td', { style: `color:${{HIGH:'#27ae60',MEDIUM:'#f39c12',LOW:'#e74c3c'}[d.confidence]||'#888'};font-weight:600` }, d.confidence || '-'),
              el('td', {}, unsupported.length ? el('span', { style: 'color:#e74c3c;font-weight:600' }, `⚠ ${unsupported.length}건`) : el('span', { style: 'color:#27ae60' }, '✅')),
              el('td', { style: 'text-align:center' }, d.masked_before_send ? el('span', { style: 'color:#27ae60;font-size:10px' }, '🔒') : el('span', { style: 'color:#999;font-size:10px' }, '-')),
              el('td', { style: 'white-space:nowrap' },
                hasEvidence && d.ver_status === 'pass' ? el('button', { className: 'btn btn-sm btn-success', style: { marginRight: 4 }, onClick: () => { Store.updateAIDraft(d.id, { human_status: 'approved', human_reviewed_at: new Date().toISOString() }); renderAIHistory() } }, '승인') : el('span', { style: 'color:#e74c3c;font-size:10px;font-weight:600;padding:4px 8px;background:#fff5f5;border-radius:4px;display:inline-block' }, !hasEvidence ? '증빙미연결' : '검증미통과'),
                el('button', { className: 'btn btn-sm btn-danger', onClick: () => { Store.updateAIDraft(d.id, { human_status: 'rejected' }); renderAIHistory() } }, '반려')
              )
            )
          }))
        ) : el('p', { style: 'padding:16px;color:#999;text-align:center' }, '검토 대기 중인 AI 초안이 없습니다.')
      ),
      el('div', { className: 'card' },
        el('div', { className: 'card-header' }, el('h3', {}, `전체 이력 (${sorted.length}건)`)),
        sorted.length ? el('table', { style: 'font-size:12px' },
          el('thead', {}, el('tr', {}, el('th', {}, '지표'), el('th', { style: 'width:50px' }, '버전'), el('th', { style: 'width:50px' }, '증빙'), el('th', { style: 'width:70px' }, '검증'), el('th', { style: 'width:70px' }, '사람검토'), el('th', { style: 'width:50px' }, '마스킹'), el('th', { style: 'width:140px' }, '생성일시'))),
          el('tbody', {}, ...sorted.slice(0, 50).map(d => {
            const ind = Store.getIndicators().find(i => i.id === d.indicator_id)
            const verColors = { pass: '#27ae60', fail: '#e74c3c', revision_needed: '#f39c12' }
            const humColors = { approved: '#27ae60', rejected: '#e74c3c', pending: '#f39c12' }
            const humLabels = { approved: '승인', rejected: '반려', pending: '대기' }
            const evCount = d.cited_evidence_ids?.length || d.evidence_ids?.length || 0
            return el('tr', {},
              el('td', {}, ind ? Indicator.getNameAndCode(ind) : d.indicator_id),
              el('td', { style: 'text-align:center' }, `v${d.version || 1}`),
              el('td', { style: 'text-align:center;font-size:11px' }, evCount ? `${evCount}건` : el('span', { style: 'color:#e74c3c' }, '0')),
              el('td', { style: `color:${verColors[d.ver_status]||'#888'};font-weight:600;text-align:center` }, d.ver_status || '-'),
              el('td', { style: `color:${humColors[d.human_status]||'#888'};font-weight:600;text-align:center` }, humLabels[d.human_status] || d.human_status),
              el('td', { style: 'text-align:center;font-size:11px' }, d.masked_before_send ? '✅' : '❌'),
              el('td', { style: 'font-size:11px;color:#888' }, d.created_at ? new Date(d.created_at).toLocaleString('ko-KR') : '-')
            )
          }))
        ) : el('p', { style: 'padding:16px;color:#999' }, '생성 이력이 없습니다.')
      )
    )
  }

  // ==================== 예산/위험관리 (S-14) ====================
  function renderBudget() {
    const c = document.getElementById('page-budget')
    if (!c) return
    const budget = Store.getProjectBudget() || []
    const risks = Store.getRiskRegister() || []
    c.innerHTML = ''
    const totalPlanned = budget.reduce((s, b) => s + (b.planned_amount || 0), 0)
    const totalActual = budget.reduce((s, b) => s + (b.actual_amount || 0), 0)
    c.append(
      el('div', { className: 'card' },
        el('div', { className: 'card-header' }, el('h3', {}, '💰 예산 관리')),
        el('div', { style: 'display:grid;grid-template-columns:repeat(auto-fit,minmax(160px,1fr));gap:12px;padding:16px 20px' },
          el('div', { className: 'stat-card' }, el('div', { className: 'stat-value' }, `₩${(totalPlanned/10000).toFixed(0)}만`), el('div', { className: 'stat-label' }, '계획 예산')),
          el('div', { className: 'stat-card' }, el('div', { className: 'stat-value' }, `₩${(totalActual/10000).toFixed(0)}만`), el('div', { className: 'stat-label' }, '집행 예산')),
          el('div', { className: 'stat-card' }, el('div', { className: 'stat-value', style: { color: totalPlanned ? (totalActual/totalPlanned > 0.9 ? '#e74c3c' : '#27ae60') : '#999' } }, totalPlanned ? Math.round(totalActual/totalPlanned*100) + '%' : '-'), el('div', { className: 'stat-label' }, '집행률'))
        )
      ),
      el('div', { className: 'card' },
        el('div', { className: 'card-header' },
          el('h3', {}, '프로젝트 예산'),
          el('button', { className: 'btn btn-primary btn-sm', onClick: () => {
            modal('예산 항목 추가', el('div', {},
              el('div', { className: 'form-group' }, el('label', {}, '카테고리'), el('select', { id: 'budCat' }, ['인건비','라이선스','외부컨설팅','인프라','기타'].map(c => el('option', { value: c }, c)))),
              el('div', { className: 'form-group' }, el('label', {}, '계획 금액'), el('input', { type: 'number', id: 'budPlanned' })),
              el('div', { className: 'form-group' }, el('label', {}, '집행 금액'), el('input', { type: 'number', id: 'budActual', value: 0 })),
              el('div', { className: 'form-group' }, el('label', {}, '단계'), el('select', { id: 'budPeriod' }, ['1단계','2단계','3단계','4단계','5단계'].map(p => el('option', { value: p }, p))))
            ))
            document.getElementById('modal-save').onclick = () => {
              Store.addProjectBudget({ category: document.getElementById('budCat').value, planned_amount: parseInt(document.getElementById('budPlanned').value) || 0, actual_amount: parseInt(document.getElementById('budActual').value) || 0, period: document.getElementById('budPeriod').value })
              closeModal(); renderBudget()
            }
          }}, '+ 추가')
        ),
        budget.length ? el('table', { style: 'font-size:12px' },
          el('thead', {}, el('tr', {}, el('th', {}, '카테고리'), el('th', { style: 'width:80px' }, '단계'), el('th', { style: 'width:100px;text-align:right' }, '계획'), el('th', { style: 'width:100px;text-align:right' }, '집행'), el('th', { style: 'width:80px;text-align:center' }, '집행률'), el('th', { style: 'width:60px' }, '관리'))),
          el('tbody', {}, ...budget.map(b => {
            const rate = b.planned_amount ? Math.round(b.actual_amount / b.planned_amount * 100) : 0
            return el('tr', {},
              el('td', {}, b.category),
              el('td', { style: 'text-align:center' }, b.period),
              el('td', { style: 'text-align:right' }, `₩${(b.planned_amount/10000).toFixed(0)}만`),
              el('td', { style: 'text-align:right' }, `₩${(b.actual_amount/10000).toFixed(0)}만`),
              el('td', { style: 'text-align:center;color:' + (rate > 100 ? '#e74c3c' : rate > 80 ? '#f39c12' : '#27ae60') }, `${rate}%`),
              el('td', {}, el('button', { className: 'btn btn-sm btn-danger', onClick: () => { Store.deleteProjectBudget(b.id); renderBudget() } }, '삭제'))
            )
          }))
        ) : el('p', { style: 'padding:16px;color:#999;text-align:center' }, '등록된 예산 항목이 없습니다.')
      ),
      el('div', { className: 'card' },
        el('div', { className: 'card-header' },
          el('h3', {}, '⚠️ 리스크 레지스터'),
          el('button', { className: 'btn btn-primary btn-sm', onClick: () => {
            modal('리스크 등록', el('div', {},
              el('div', { className: 'form-group' }, el('label', {}, '리스크 이름'), el('input', { id: 'riskName' })),
              el('div', { className: 'form-group' }, el('label', {}, '리스크 설명'), el('textarea', { id: 'riskDesc', rows: 2, style: 'width:100%;padding:8px;border:1px solid #ddd;border-radius:6px' })),
              el('div', { style: 'display:grid;grid-template-columns:1fr 1fr;gap:8px' },
                el('div', { className: 'form-group' }, el('label', {}, '확률(1-5)'), el('input', { type: 'number', id: 'riskProb', min: 1, max: 5, value: 3 })),
                el('div', { className: 'form-group' }, el('label', {}, '영향(1-5)'), el('input', { type: 'number', id: 'riskImpact', min: 1, max: 5, value: 3 }))
              ),
              el('div', { className: 'form-group' }, el('label', {}, '대응 방안'), el('textarea', { id: 'riskMit', rows: 2, style: 'width:100%;padding:8px;border:1px solid #ddd;border-radius:6px' })),
              el('div', { className: 'form-group' }, el('label', {}, '담당자'), el('input', { id: 'riskOwner' }))
            ))
            document.getElementById('modal-save').onclick = () => {
              Store.addRiskRegister({ risk_name: document.getElementById('riskName').value, description: document.getElementById('riskDesc').value, probability: parseInt(document.getElementById('riskProb').value), impact: parseInt(document.getElementById('riskImpact').value), mitigation_plan: document.getElementById('riskMit').value, owner: document.getElementById('riskOwner').value, category: 'other', status: 'identified' })
              closeModal(); renderBudget()
            }
          }}, '+ 리스크 등록')
        ),
        risks.length ? el('table', { style: 'font-size:12px' },
          el('thead', {}, el('tr', {}, el('th', {}, '이름'), el('th', {}, '설명'), el('th', { style: 'width:50px' }, '확률'), el('th', { style: 'width:50px' }, '영향'), el('th', { style: 'width:60px' }, '점수'), el('th', {}, '대응방안'), el('th', { style: 'width:60px' }, '담당자'), el('th', { style: 'width:50px' }, '관리'))),
          el('tbody', {}, ...risks.sort((a,b) => (b.probability*b.impact) - (a.probability*a.impact)).map(r => {
            const score = r.probability * r.impact
            const color = score >= 15 ? '#e74c3c' : score >= 8 ? '#f39c12' : '#27ae60'
            return el('tr', {},
              el('td', {}, r.risk_name || ''),
              el('td', { style: 'font-size:11px' }, r.description || ''),
              el('td', { style: 'text-align:center' }, r.probability),
              el('td', { style: 'text-align:center' }, r.impact),
              el('td', { style: `text-align:center;color:${color};font-weight:700` }, score),
              el('td', { style: 'font-size:11px' }, r.mitigation_plan || ''),
              el('td', { style: 'font-size:11px' }, r.owner || ''),
              el('td', {}, el('button', { className: 'btn btn-sm btn-danger', onClick: () => { Store.deleteRiskRegister(r.id); renderBudget() } }, '삭제'))
            )
          }))
        ) : el('p', { style: 'padding:16px;color:#999;text-align:center' }, '등록된 리스크가 없습니다.')
      )
    )
  }

  // ==================== 민감정보 마스킹 설정 (S-15) ====================
  function renderMasking() {
    const c = document.getElementById('page-masking')
    if (!c) return
    const rules = Store.getMaskingRules() || []
    c.innerHTML = ''
    c.append(
      el('div', { className: 'card' },
        el('div', { className: 'card-header' },
          el('h3', {}, '🔒 민감정보 마스킹 설정'),
          el('button', { className: 'btn btn-primary btn-sm', onClick: () => {
            modal('마스킹 규칙 추가', el('div', {},
              el('div', { className: 'form-group' }, el('label', {}, '필드명'), el('input', { id: 'maskField', placeholder: '예: 급여, 징계이력' })),
              el('div', { className: 'form-group' }, el('label', {}, '마스킹 유형'), el('select', { id: 'maskType' }, ['전체마스킹','부분마스킹','집계치만허용'].map(t => el('option', { value: t }, t)))),
              el('div', { className: 'form-group' }, el('label', { style: 'display:flex;align-items:center;gap:8px' }, el('input', { type: 'checkbox', id: 'maskAI', checked: true }), 'AI 외부 API 전송 시 적용'))
            ))
            document.getElementById('modal-save').onclick = () => {
              Store.addMaskingRule({ field_name: document.getElementById('maskField').value, masking_type: document.getElementById('maskType').value, applies_to_ai_api: document.getElementById('maskAI').checked })
              closeModal(); renderMasking()
            }
          }}, '+ 규칙 추가')
        ),
        el('div', { style: 'padding:12px 20px;background:#f8f9fa;border-bottom:1px solid #eee;font-size:12px;color:#666;line-height:1.6' },
          'AI 프롬프트 전송 전 민감정보를 자동 마스킹합니다.',
          el('br'),
          '전체마스킹: [마스킹됨] / 부분마스킹:첫 2글자+** / 집계치만허용: 개별값 숨김, 합계만 노출'
        ),
        rules.length ? el('table', { style: 'font-size:12px' },
          el('thead', {}, el('tr', {}, el('th', {}, '필드명'), el('th', {}, '마스킹 유형'), el('th', { style: 'width:120px' }, 'AI API 적용'), el('th', { style: 'width:60px' }, '관리'))),
          el('tbody', {}, ...rules.map(r => el('tr', {},
            el('td', { style: 'font-weight:500' }, r.field_name),
            el('td', {}, r.masking_type),
            el('td', { style: 'text-align:center;color:' + (r.applies_to_ai_api ? '#27ae60' : '#999') }, r.applies_to_ai_api ? '✅ 적용' : '❌ 미적용'),
            el('td', {}, el('button', { className: 'btn btn-sm btn-danger', onClick: () => { Store.deleteMaskingRule(r.id); renderMasking() } }, '삭제'))
          ))
        )) : el('p', { style: 'padding:16px;color:#999;text-align:center' }, '설정된 마스킹 규칙이 없습니다.')
      ),
      el('div', { className: 'card' },
        el('div', { className: 'card-header' }, el('h3', {}, 'AI 전송 마스킹 미리보기')),
        el('div', { style: 'padding:16px 20px;font-size:12px' },
          el('div', { style: 'margin-bottom:8px;color:#666' }, '마스킹이 적용된 증빙 데이터 (AI 프롬프트에 전달되는 형태):'),
          el('table', { style: 'font-size:11px;width:100%' },
            el('thead', {}, el('tr', {}, el('th', {}, '원본'), el('th', {}, '마스킹 결과'))),
            el('tbody', {},
              rules.map(r => {
                const examples = { '전체마스킹': '[마스킹됨]', '부분마스킹': '김**', '집계치만허용': '(합계: 5,200만원)' }
                return el('tr', {}, el('td', {}, r.field_name), el('td', { style: 'color:#e74c3c;font-weight:500' }, examples[r.masking_type] || '-'))
              })
            )
          )
        )
      )
    )
  }

  // ==================== 대시보드 ====================
  let _dashAssId = null
  function renderDashboard() {
    const c = document.getElementById('page-dashboard')
    if (!c) return
    const assessments = Store.getAssessments() || []
    c.innerHTML = ''
    if (!assessments.length) {
      c.append(
        el('div', { className: 'card', style: 'text-align:center;padding:60px 40px' },
          el('div', { style: 'font-size:48px;margin-bottom:16px' }, '📊'),
          el('h2', { style: 'margin:0 0 8px;color:#2c3e50' }, 'Smart ESG에 오신 것을 환영합니다'),
          el('p', { style: 'margin:0 0 24px;color:#888;font-size:14px;line-height:1.6' }, 'ESG 평가를 시작하려면 먼저 평가를 생성하세요.\n평가 기관(EcoVadis, KSSB 등)을 선택하고 자사 데이터를 입력하면 자동으로 점수와 등급이 산정됩니다.'),
          el('button', { className: 'btn btn-primary', style: 'font-size:16px;padding:12px 32px', onClick: () => navigate('assessment') }, '+ 첫 번째 평가 만들기'),
          el('div', { style: 'margin-top:32px;display:grid;grid-template-columns:repeat(auto-fit,minmax(200px,1fr));gap:16px;text-align:left' },
            el('div', { style: 'padding:16px;background:#f8f6ff;border-radius:10px;border-left:3px solid #7C3AED' },
              el('div', { style: 'font-weight:600;font-size:13px;margin-bottom:4px' }, '1단계: 평가 생성'),
              el('div', { style: 'font-size:12px;color:#666' }, '평가 기관과 대상 연도를 선택합니다')
            ),
            el('div', { style: 'padding:16px;background:#f0f7ff;border-radius:10px;border-left:3px solid #3B82F6' },
              el('div', { style: 'font-weight:600;font-size:13px;margin-bottom:4px' }, '2단계: 지표 점수 입력'),
              el('div', { style: 'font-size:12px;color:#666' }, '각 지표별 자사 점수를 입력합니다')
            ),
            el('div', { style: 'padding:16px;background:#f0fff4;border-radius:10px;border-left:3px solid #10B981' },
              el('div', { style: 'font-weight:600;font-size:13px;margin-bottom:4px' }, '3단계: 보고서 생성'),
              el('div', { style: 'font-size:12px;color:#666' }, 'AI가 자동으로 보고서 초안을 작성합니다')
            )
          )
        )
      )
      return
    }
    _dashAssId = _dashAssId || assessments[0]?.id
    if (!assessments.find(a => a.id === _dashAssId)) _dashAssId = assessments[0]?.id
    c.append(
      el('div', { style: 'display:flex;gap:8px;margin-bottom:12px;align-items:center' },
        el('select', { id: 'dashAssSelect', onChange: () => { _dashAssId = parseInt(document.getElementById('dashAssSelect').value); renderDashboard() } },
          ...assessments.map(a => el('option', { value: a.id, selected: a.id === _dashAssId }, `${a.title} (${a.assessment_year}년)`))
        ),
        el('button', { className: 'btn btn-primary', onClick: () => Report.print(_dashAssId) }, '🖨 보고서 출력'),
        el('button', { className: 'btn btn-secondary', onClick: () => Report.downloadHTML(_dashAssId) }, '⬇ HTML 다운로드')
      ),
      el('div', { id: 'dashGrid' })
    )
    Dashboard.render('dashGrid', _dashAssId)
  }

  // ==================== Settings: Companies ====================
  function renderCompanies() {
    const c = document.getElementById('companies-content')
    const companies = Store.getCompanies()
    c.innerHTML = ''
    c.append(
      el('div', { className: 'card' },
        el('div', { className: 'card-header' },
          el('h3', {}, '회사 정보'),
          el('button', { className: 'btn btn-primary', onClick: openAddCompany }, '+ 회사 추가')
        ),
        companies.length ? sortableTable('companies', [
          { label: '회사명', key: 'name', value: cp => cp.name || '-' },
          { label: '대표', key: 'representative' },
          { label: '사업자번호', key: 'business_no' },
          { label: '업종', key: 'industry' }
        ], companies, {
          bulkDelete: id => Store.deleteCompany(id),
          actions: cp => [
            el('button', { className: 'btn btn-sm btn-danger', onClick: () => { if (confirm('삭제?')) { Store.deleteCompany(cp.id); renderCompanies() } } }, '삭제')
          ]
        }) : el('p', { style: 'padding:20px;color:#999' }, '등록된 회사가 없습니다.')
      )
    )
  }

  function openAddCompany() {
    const form = el('form', { onSubmit: e => e.preventDefault() })
    const name = el('input', { required: true })
    const rep = el('input')
    const biz = el('input')
    const ind = el('input')
    form.append(el('label', {}, '회사명 *', name), el('label', {}, '대표자', rep), el('label', {}, '사업자번호', biz), el('label', {}, '업종', ind))
    modal('회사 추가', form)
    document.getElementById('modal-save').onclick = () => {
      Store.addCompany({ name: name.value, representative: rep.value, business_no: biz.value, industry: ind.value })
      closeModal(); renderCompanies()
    }
  }

  // ==================== Settings: Departments ====================
  function renderDepartments() {
    const c = document.getElementById('departments-content')
    const departments = Store.getDepartments()
    c.innerHTML = ''
    c.append(
      el('div', { className: 'card' },
        el('div', { className: 'card-header' },
          el('h3', {}, `부서 관리 (${departments.length}개)`),
          el('button', { className: 'btn btn-primary', onClick: openAddDepartment }, '+ 부서 추가')
        ),
        departments.length ? sortableTable('departments', [
          { label: '부서코드', key: 'dept_code', value: d => el('span', { style: 'font-family:monospace;font-weight:600' }, d.dept_code) },
          { label: '부서명', key: 'dept_name' },
          { label: '담당자', key: 'manager_name', value: d => d.manager_name || '-' },
          { label: '이메일', key: 'manager_email', value: d => d.manager_email || '-' },
          { label: '상위부서', key: 'parent_dept', value: d => d.parent_dept || '-' },
          { label: '상태', value: d => el('span', { className: 'badge ' + (d.is_active !== false ? 'badge-paid' : 'badge-unpaid') }, d.is_active !== false ? '활성' : '비활성') }
        ], departments, {
          bulkDelete: id => Store.deleteDepartment(id),
          actions: d => [
            el('button', { className: 'btn btn-sm btn-secondary', style: { marginRight: 4 }, onClick: () => editDepartment(d.id) }, '수정'),
            el('button', { className: 'btn btn-sm btn-danger', onClick: () => { if (confirm('삭제?')) { Store.deleteDepartment(d.id); renderDepartments() } } }, '삭제')
          ]
        }) : el('p', { style: 'padding:20px;color:#999' }, '등록된 부서가 없습니다.')
      )
    )
  }

  function openAddDepartment() { createDepartmentModal() }
  function editDepartment(id) { const dept = Store.getDepartments().find(x => x.id === id); if (dept) createDepartmentModal(dept) }

  function createDepartmentModal(dept) {
    const isEdit = !!dept
    const form = el('form', { onSubmit: e => e.preventDefault() })
    const deptCode = el('input', { value: dept?.dept_code ?? '', required: true, placeholder: '예: ENV, HR, FIN' })
    const deptName = el('input', { value: dept?.dept_name ?? '', required: true, placeholder: '예: 환경팀' })
    const managerName = el('input', { value: dept?.manager_name ?? '', placeholder: '예: 김철수' })
    const managerEmail = el('input', { type: 'email', value: dept?.manager_email ?? '', placeholder: '예: team@company.com' })
    const parentDept = el('select', {},
      el('option', { value: '' }, '(없음)'),
      ...Store.getDepartments().filter(d => d.is_active !== false && d.dept_code !== dept?.dept_code).map(d => el('option', { value: d.dept_code, selected: dept?.parent_dept === d.dept_code }, d.dept_name))
    )
    const isActive = el('input', { type: 'checkbox', checked: dept?.is_active !== false })

    form.append(
      el('div', { className: 'form-group' }, el('label', {}, '부서코드 *'), deptCode),
      el('div', { className: 'form-group' }, el('label', {}, '부서명 *'), deptName),
      el('div', { style: 'display:grid;grid-template-columns:1fr 1fr;gap:8px' },
        el('div', { className: 'form-group' }, el('label', {}, '담당자'), managerName),
        el('div', { className: 'form-group' }, el('label', {}, '담당자 이메일'), managerEmail)
      ),
      el('div', { className: 'form-group' }, el('label', {}, '상위부서'), parentDept),
      el('div', { className: 'form-group' }, el('label', { style: 'display:flex;align-items:center;gap:8px' }, isActive, '활성'))
    )
    modal(isEdit ? '부서 수정' : '부서 추가', form)
    document.getElementById('modal-save').onclick = () => {
      try {
        if (!deptCode.value.trim()) return alert('부서코드를 입력하세요')
        if (!deptName.value.trim()) return alert('부서명을 입력하세요')
        const data = {
          dept_code: deptCode.value.trim().toUpperCase(),
          dept_name: deptName.value.trim(),
          manager_name: managerName.value.trim(),
          manager_email: managerEmail.value.trim(),
          parent_dept: parentDept.value,
          is_active: isActive.checked
        }
        if (isEdit) Store.updateDepartment(dept.id, data)
        else Store.addDepartment(data)
        closeModal(); renderDepartments()
      } catch (err) {
        alert('저장 중 오류 발생: ' + err.message)
        console.error('Department save error:', err)
      }
    }
  }

  // ==================== Settings: Weights & Thresholds ====================
  function renderWeights() {
    const c = document.getElementById('weights-content')
    const params = Store.getWeightParams()
    const thresholds = Store.getRatingThresholds()
    const years = [...new Set([...params.map(p => p.year), ...thresholds.map(t => t.year), 2026])].sort()
    const year = years[years.length - 1]
    c.innerHTML = ''
    c.append(
      el('div', { className: 'card' },
        el('div', { className: 'card-header' }, el('h3', {}, `테마별 가중치 (${year}년)`)),
        el('table', { className: 'table-dense' },
          el('thead', {}, el('tr', {}, el('th', {}, '기관'), el('th', {}, '그룹'), el('th', {}, '가중치(%)'))),
          el('tbody', {}, ...['ECOVADIS', 'KSSB', 'KCGS', 'NICE', 'K-ESG'].map(auth => {
            const authParams = params.filter(p => p.authority_code === auth && p.year === year && p.group_code !== '_PILLAR')
            if (!authParams.length) return el('tr', {}, el('td', { colspan: 3, style: 'color:#999;text-align:center' }, `${Indicator.getAuthorityName(auth)}: 설정된 가중치 없음`))
            return authParams.map(p => el('tr', {},
              el('td', {}, Indicator.getAuthorityName(auth)),
              el('td', {}, p.group_code),
              el('td', {},
                el('input', { type: 'number', min: 0, max: 100, value: p.weight_pct, style: 'width:60px;padding:4px;border:1px solid #ddd;border-radius:4px;text-align:center', onBlur: e => { Store.updateWeightParam(p.id, { weight_pct: parseInt(e.target.value) || 0 }) } })
              )
            ))
          }).flat())
        )
      ),
      el('div', { className: 'card' },
        el('div', { className: 'card-header' }, el('h3', {}, `필러별 가중치 - EcoVadis (${year}년)`)),
        el('div', { style: 'padding:12px 16px;background:#f8f6ff;border-bottom:1px solid #eee;font-size:12px;color:#666' },
          'EcoVadis 공식 기준: POLICY 25% / ACTION 40% / RESULT 35%'
        ),
        el('table', { className: 'table-dense' },
          el('thead', {}, el('tr', {}, el('th', {}, '필러'), el('th', {}, '가중치(%)'), el('th', {}, '해석'))),
          el('tbody', {}, ...['POLICY', 'ACTION', 'RESULT'].map(p => {
            const pw = params.find(pp => pp.authority_code === 'ECOVADIS' && pp.group_code === '_PILLAR' && pp.pillar === p && pp.year === year)
            const interp = { POLICY: '정책 수립 여부 및 범위', ACTION: '조치·이행 (측정·인증·전개도)', RESULT: '결과·보고 (KPI·360° Watch)' }
            return el('tr', {},
              el('td', { style: 'font-weight:500' }, `${Indicator.getPillarName(p)} (${p})`),
              el('td', {}, el('input', { type: 'number', min: 0, max: 100, value: pw?.weight_pct ?? 0, style: 'width:60px;padding:4px;border:1px solid #ddd;border-radius:4px;text-align:center', onBlur: e => {
                if (pw) Store.updateWeightParam(pw.id, { weight_pct: parseInt(e.target.value) || 0 })
              } })),
              el('td', { style: 'font-size:12px;color:#888' }, interp[p] || '')
            )
          }))
        )
      ),
      el('div', { className: 'card' },
        el('div', { className: 'card-header' }, el('h3', {}, `등급 기준 (${year}년)`)),
        el('table', { className: 'table-dense' },
          el('thead', {}, el('tr', {}, el('th', {}, '기관'), el('th', {}, '등급'), el('th', {}, '최소'), el('th', {}, '최대'))),
          el('tbody', {}, ...['ECOVADIS', 'KSSB', 'KCGS', 'NICE', 'K-ESG'].map(auth => {
            const authThresholds = thresholds.filter(t => t.authority_code === auth && t.year === year).sort((a, b) => b.min_score - a.min_score)
            if (!authThresholds.length) return el('tr', {}, el('td', { colspan: 4, style: 'color:#999;text-align:center' }, `${Indicator.getAuthorityName(auth)}: 설정된 등급 기준 없음`))
            return authThresholds.map(t => el('tr', {},
              el('td', {}, Indicator.getAuthorityName(auth)),
              el('td', { style: 'font-weight:600' }, t.rating),
              el('td', {}, el('input', { type: 'number', value: t.min_score, style: 'width:50px;padding:4px;border:1px solid #ddd;border-radius:4px;text-align:center', onBlur: e => { Store.updateRatingThreshold(t.id, { min_score: parseInt(e.target.value) || 0 }) } })),
              el('td', {}, el('input', { type: 'number', value: t.max_score, style: 'width:50px;padding:4px;border:1px solid #ddd;border-radius:4px;text-align:center', onBlur: e => { Store.updateRatingThreshold(t.id, { max_score: parseInt(e.target.value) || 100 }) } }))
            ))
          }).flat())
        )
      )
    )
  }

  // ==================== Settings: Users ====================
  function switchSettingsTab(tabId) {
    document.querySelectorAll('#page-settings .tab').forEach(t => t.classList.remove('active'))
    document.querySelectorAll('#page-settings .tab-content').forEach(c => c.classList.remove('active'))
    const tab = document.querySelector(`#page-settings .tab[data-stab="${tabId}"]`)
    if (tab) tab.classList.add('active')
    const panel = document.getElementById(tabId)
    if (panel) panel.classList.add('active')
    if (tabId === 'tab-users') renderUsers()
    if (tabId === 'tab-mobile') {
      const saved = localStorage.getItem('smart_esg_mobile_url')
      const input = document.getElementById('mobile-url')
      if (input) { input.value = saved || ''; updateQR() }
    }
    if (tabId === 'tab-companies') renderCompanies()
    if (tabId === 'tab-departments') renderDepartments()
    if (tabId === 'tab-weights') renderWeights()
  }

  function switchUserListTab(tab) {
    _userListTab = tab
    document.querySelectorAll('#tab-users .card-header .btn').forEach(b => {
      const isPending = b.textContent.includes('승인대기')
      b.style.background = isPending === (tab === 'pending') ? '#2d5427' : '#e8eaed'
      b.style.color = isPending === (tab === 'pending') ? '#fff' : '#555'
    })
    renderUsers()
  }

  function renderUsers() {
    const tbody = document.getElementById('user-tbody')
    if (!tbody) return
    let users = Store.getUsers()
    if (_userListTab === 'pending') users = users.filter(u => u.status !== 'active')
    const q = (document.getElementById('user-search')?.value || '').toLowerCase()
    if (q) users = users.filter(u => (u.name || '').toLowerCase().includes(q) || (u.username || '').toLowerCase().includes(q))
    const pc = document.getElementById('pending-count')
    if (pc) pc.textContent = Store.getUsers().filter(u => u.status !== 'active').length
    if (!users.length) { tbody.innerHTML = '<tr><td colspan="10">' + (_userListTab === 'pending' ? '승인 대기 중인 회원이 없습니다.' : '등록된 사용자가 없습니다.') + '</td></tr>'; return }
    const table = sortableTable('users', [
      { label: '아이디', key: 'username' },
      { label: '이름', key: 'name', value: u => u.name || '-' },
      { label: '부서', key: 'dept_code', value: u => u.dept_code || '-' },
      { label: '직급', key: 'position', value: u => u.position || '-' },
      { label: '이메일', key: 'email', value: u => u.email || '-' },
      { label: '연락처', key: 'phone', value: u => u.phone || '-' },
      { label: '권한', value: u => el('span', { className: 'badge ' + (u.role === 'admin' ? 'badge-paid' : 'badge-pending') }, { admin: '관리자', manager: '매니저', user: '사용자', viewer: '뷰어' }[u.role] || u.role) },
      { label: '상태', value: u => u.status !== 'active' ? el('span', { className: 'badge badge-unpaid' }, '승인대기') : el('span', { className: 'badge badge-paid' }, '활성') },
      { label: '가입일', key: 'createdAt', value: u => u.createdAt || '-' }
    ], users, {
      bulkDelete: id => {
        if (currentUser && currentUser.id === id) return
        Store.deleteUser(id)
      },
      actions: u => {
        const isPending = u.status !== 'active'
        const canDelete = currentUser && currentUser.id !== u.id
        return [
          isPending ? el('button', { className: 'btn btn-sm btn-primary', style: { marginRight: 4 }, onClick: () => approveUser(u.id) }, '승인') : null,
          el('button', { className: 'btn btn-sm btn-secondary', style: { marginRight: 4 }, onClick: () => editUser(u.id) }, '수정'),
          canDelete ? el('button', { className: 'btn btn-sm btn-danger', onClick: () => deleteUser(u.id) }, '삭제') : null
        ].filter(Boolean)
      }
    })
    const wrap = tbody.closest('.table-wrap')
    if (wrap) { wrap.innerHTML = ''; wrap.append(table) }
    else { tbody.innerHTML = ''; tbody.append(table) }
  }

  function approveUser(id) {
    if (!currentUser) return alert('로그인이 필요합니다.')
    Store.updateUser(id, { status: 'active' })
    const pc = document.getElementById('pending-count')
    if (pc) pc.textContent = Store.getUsers().filter(u => u.status !== 'active').length
    if (_userListTab === 'pending' && Store.getUsers().filter(u => u.status !== 'active').length === 0) switchUserListTab('all')
    else renderUsers()
  }

  function editUser(id) {
    const user = Store.getUsers().find(x => x.id === id)
    if (!user) return
    const form = document.createElement('form')
    const companies = Store.getCompanies()
    const depts = Store.getDepartments().filter(d => d.is_active !== false)
    const companyOptions = companies.map(c => `<option value="${c.id}" ${user.company_id === c.id ? 'selected' : ''}>${c.name}</option>`).join('')
    const deptOptions = depts.map(d => `<option value="${d.dept_code}" ${user.dept_code === d.dept_code ? 'selected' : ''}>${d.dept_name}</option>`).join('')
    form.innerHTML = `
      <div class="form-group"><label>아이디</label><input id="f-uid" value="${esc(user.username)}" readonly style="background:#f5f5f5"></div>
      <div class="form-group"><label>이름</label><input id="f-uname" value="${esc(user.name || '')}"></div>
      <div class="form-group"><label>회사</label><select id="f-ucompany"><option value="">선택</option>${companyOptions}</select></div>
      <div class="form-group"><label>부서</label><select id="f-udept"><option value="">선택</option>${deptOptions}</select></div>
      <div class="form-group"><label>직급</label><input id="f-uposition" value="${esc(user.position || '')}"></div>
      <div class="form-group"><label>이메일</label><input id="f-uemail" type="email" value="${esc(user.email || '')}"></div>
      <div class="form-group"><label>연락처</label><input id="f-uphone" value="${esc(user.phone || '')}"></div>
      <div class="form-group"><label>권한</label><select id="f-urole"><option value="user" ${user.role === 'user' ? 'selected' : ''}>사용자</option><option value="admin" ${user.role === 'admin' ? 'selected' : ''}>관리자</option><option value="manager" ${user.role === 'manager' ? 'selected' : ''}>매니저</option><option value="viewer" ${user.role === 'viewer' ? 'selected' : ''}>뷰어</option></select></div>
      <div class="form-group"><label>상태</label><select id="f-ustatus"><option value="active" ${user.status === 'active' ? 'selected' : ''}>활성</option><option value="pending" ${user.status === 'pending' ? 'selected' : ''}>승인대기</option><option value="inactive" ${user.status === 'inactive' ? 'selected' : ''}>비활성</option></select></div>`
    modal('사용자 수정', form)
    document.getElementById('modal-save').onclick = function() {
      Store.updateUser(id, { name: document.getElementById('f-uname').value, company_id: document.getElementById('f-ucompany').value ? parseInt(document.getElementById('f-ucompany').value) : null, dept_code: document.getElementById('f-udept').value, position: document.getElementById('f-uposition').value, email: document.getElementById('f-uemail').value, phone: document.getElementById('f-uphone').value, role: document.getElementById('f-urole').value, status: document.getElementById('f-ustatus').value })
      closeModal(); renderUsers()
    }
  }

  function deleteUser(id) {
    if (!confirm('정말 삭제하시겠습니까?')) return
    Store.deleteUser(id)
    renderUsers()
  }

  function cleanupUsers() {
    if (!currentUser) return alert('로그인이 필요합니다.')
    const pending = Store.getUsers().filter(u => u.id !== currentUser.id && u.status !== 'active')
    if (!pending.length) return alert('미승인 대기 회원이 없습니다.')
    if (!confirm(`미승인 회원 ${pending.length}명을 삭제하시겠습니까?`)) return
    if (!confirm('정말입니까? 이 작업은 되돌릴 수 없습니다.')) return
    pending.forEach(u => Store.deleteUser(u.id))
    const pc = document.getElementById('pending-count')
    if (pc) pc.textContent = Store.getUsers().filter(u => u.status !== 'active').length
    renderUsers()
    alert(`${pending.length}명의 미승인 회원이 삭제되었습니다.`)
  }

  // ==================== Settings: Keep-alive ====================
  let _keepAliveTimer = null

  function toggleKeepAlive(on) {
    localStorage.setItem('smart_esg_keepalive', on ? '1' : '0')
    const status = document.getElementById('keepalive-status')
    const slider = document.getElementById('keepalive-slider')
    if (on) {
      slider.style.background = '#7C3AED'
      status.textContent = '🟢 실행 중 — 6일마다 Supabase 자동 접속'
      _doKeepAlive()
      _keepAliveTimer = setInterval(_doKeepAlive, 6 * 24 * 60 * 60 * 1000)
    } else {
      slider.style.background = '#ccc'
      status.textContent = '⏹ 중지됨'
      if (_keepAliveTimer) { clearInterval(_keepAliveTimer); _keepAliveTimer = null }
    }
  }

  async function _doKeepAlive() {
    try {
      const sb = getSupabase()
      if (!sb) return
      await sb.auth.getSession()
      const status = document.getElementById('keepalive-status')
      if (status) status.textContent = '🟢 실행 중 — 마지막 접속: ' + new Date().toLocaleTimeString('ko-KR')
    } catch (e) { console.warn('Keep-alive error:', e) }
  }

  function initKeepAlive() {
    const saved = localStorage.getItem('smart_esg_keepalive') === '1'
    const toggle = document.getElementById('keepalive-toggle')
    if (toggle) {
      toggle.checked = saved
      const slider = document.getElementById('keepalive-slider')
      if (slider) slider.style.background = saved ? '#7C3AED' : '#ccc'
    }
    if (saved) { _keepAliveTimer = setInterval(_doKeepAlive, 6 * 24 * 60 * 60 * 1000); _doKeepAlive() }
  }

  // ==================== Settings: Mobile QR ====================
  function updateQR() {
    const input = document.getElementById('mobile-url')
    if (!input) return
    const url = input.value.trim()
    if (!url) { const img = document.getElementById('qr-image'); if (img) img.style.display = 'none'; return }
    localStorage.setItem('smart_esg_mobile_url', url)
    const img = document.getElementById('qr-image')
    if (!img) return
    img.style.display = 'block'
    img.src = 'https://api.qrserver.com/v1/create-qr-code/?size=480x480&data=' + encodeURIComponent(url)
  }

  // ==================== Auth helpers ====================
  function doLogoutUI() {
    logout().then(() => { currentUser = null; init() })
  }

  // ==================== Modal System ====================
  function closeModal(e) {
    if (e && e.target !== document.getElementById('modal-overlay') && !e.target.closest('#modal')) return
    document.getElementById('modal-overlay').classList.add('hidden')
  }

  function saveModal() {
    // Overridden per modal
  }

  // ==================== Expose globals ====================
  window.init = init
  window.navigate = navigate
  window.switchSettingsTab = switchSettingsTab
  window.switchUserListTab = switchUserListTab
  window.renderUsers = renderUsers
  window.approveUser = approveUser
  window.editUser = editUser
  window.deleteUser = deleteUser
  window.cleanupUsers = cleanupUsers
  window.toggleKeepAlive = toggleKeepAlive
  window.toggleHelp = toggleHelp
  window.initKeepAlive = initKeepAlive
  window.updateQR = updateQR
  window.doLogoutUI = doLogoutUI
  window.closeModal = closeModal
  window.saveModal = saveModal
  window.renderAssessments = renderAssessments
  window.renderIndicators = renderIndicators
  window.renderDashboard = renderDashboard
  window.showAssessmentDetail = showAssessmentDetail
  window.renderCompanies = renderCompanies
  window.renderDepartments = renderDepartments
  window.renderWeights = renderWeights
  window.openAddCompany = openAddCompany
  window.openAddDepartment = openAddDepartment
  window.editDepartment = editDepartment
  window.renderGRI = renderGRI
  window.renderRisk = renderRisk
  window.renderMonitor = renderMonitor
  window.renderISSA = renderISSA
  window.renderSubmit = renderSubmit
  window.renderAPI = renderAPI
  window.renderReportEditor = renderReportEditor
  window.renderKSSB = renderKSSB
  window.renderAIHistory = renderAIHistory
  window.renderBudget = renderBudget
  window.renderMasking = renderMasking

  document.addEventListener('DOMContentLoaded', _initApp)
  if (document.readyState !== 'loading') _initApp()

  function _initApp() {
    if (_initApp._done) return
    _initApp._done = true
    document.addEventListener('click', e => {
      const a = e.target.closest('#nav a[data-page]')
      if (a) { e.preventDefault(); navigate(a.dataset.page) }
    })
    document.getElementById('help-btn')?.addEventListener('click', toggleHelp)
    document.getElementById('sidebar-logo')?.addEventListener('click', () => navigate('dashboard'))
    document.getElementById('sb-collapse-btn')?.addEventListener('click', function() {
      const sb = document.getElementById('sidebar')
      sb.classList.toggle('collapsed')
      this.textContent = sb.classList.contains('collapsed') ? '▶' : '◀'
    })
    init()
  }
})()
